import axios from 'axios';
import type {
  Asset,
  Caption,
  CreateProjectPayload,
  ExportJob,
  ExportPayload,
  GenerateCaptionsPayload,
  ProjectDetail,
  ProjectSummary,
  Timeline,
  UpdateCaptionPayload,
  UpdateProjectPayload,
} from './types';

const API_BASE = process.env.NEXT_PUBLIC_AI_SERVER_URL || 'http://localhost:8000';

export const api = axios.create({
  baseURL: API_BASE,
  timeout: 300000,
});

export function getAssetUrl(projectId: string, assetId: string) {
  return `${API_BASE}/projects/${projectId}/assets/${assetId}/file`;
}

export function getDownloadUrl(exportId: string) {
  return `${API_BASE}/download/${exportId}`;
}

export async function checkHealth() {
  try {
    const res = await api.get('/health');
    return res.data;
  } catch {
    return null;
  }
}

export async function getProjects() {
  const res = await api.get<{ projects: ProjectSummary[] }>('/projects');
  return res.data.projects;
}

export async function createProject(payload: CreateProjectPayload) {
  const res = await api.post<ProjectDetail>('/projects', payload);
  return res.data;
}

export async function getProject(projectId: string) {
  const res = await api.get<ProjectDetail>(`/projects/${projectId}`);
  return res.data;
}

export async function updateProject(projectId: string, payload: UpdateProjectPayload) {
  const res = await api.patch<ProjectDetail>(`/projects/${projectId}`, payload);
  return res.data;
}

export async function deleteProject(projectId: string) {
  const res = await api.delete(`/projects/${projectId}`);
  return res.data;
}

export async function uploadAsset(projectId: string, file: File, role = 'source') {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('role', role);
  const res = await api.post<{ success: boolean; asset: Asset; project: ProjectDetail }>(
    `/projects/${projectId}/assets`,
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } },
  );
  return res.data;
}

export async function generateCaptions(projectId: string, payload: GenerateCaptionsPayload) {
  const res = await api.post<{ project_id: string; status: string; message: string }>(
    `/projects/${projectId}/generate-captions`,
    payload,
  );
  return res.data;
}

export async function getTimeline(projectId: string) {
  const res = await api.get<Timeline>(`/projects/${projectId}/timeline`);
  return res.data;
}

export async function replaceTimeline(projectId: string, timeline: Timeline) {
  const res = await api.put<{ success: boolean; timeline: Timeline }>(`/projects/${projectId}/timeline`, timeline);
  return res.data.timeline;
}

export async function updateCaption(projectId: string, captionId: string, payload: UpdateCaptionPayload) {
  const res = await api.patch<{ success: boolean; caption: Caption }>(
    `/projects/${projectId}/captions/${captionId}`,
    payload,
  );
  return res.data.caption;
}

export async function deleteCaption(projectId: string, captionId: string) {
  const res = await api.delete(`/projects/${projectId}/captions/${captionId}`);
  return res.data;
}

export async function splitCaption(projectId: string, captionId: string, splitAt: number) {
  const formData = new FormData();
  formData.append('split_at', String(splitAt));
  const res = await api.post<{ success: boolean; captions: Caption[] }>(
    `/projects/${projectId}/captions/${captionId}/split`,
    formData,
    { headers: { 'Content-Type': 'multipart/form-data' } },
  );
  return res.data.captions;
}

export async function mergeCaption(projectId: string, captionId: string) {
  const res = await api.post<{ success: boolean; caption: Caption }>(
    `/projects/${projectId}/captions/${captionId}/merge-next`,
  );
  return res.data.caption;
}

export async function getPreview(projectId: string) {
  const res = await api.get(`/projects/${projectId}/preview`);
  return res.data;
}

export async function getPreviewHtml(projectId: string) {
  const res = await api.get(`/projects/${projectId}/preview-html`, { responseType: 'blob' });
  return res.data as Blob;
}

export async function exportProject(projectId: string, payload: ExportPayload) {
  const res = await api.post<{ export_id: string; status: string }>(`/projects/${projectId}/export`, payload);
  return res.data;
}

export async function getExport(exportId: string) {
  const res = await api.get<ExportJob>(`/export/${exportId}`);
  return res.data;
}

export async function listThemes() {
  const res = await api.get('/themes');
  return res.data.themes as Array<{ id: string; name: string; description: string }>;
}

export async function listStyles() {
  const res = await api.get('/styles');
  return res.data as { styles: Array<{ id: string; name: string }>; animations: Array<{ id: string; name: string }> };
}

// Legacy compatibility for the previous upload-only flow.
export async function uploadVideo(file: File, language = 'auto') {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('language', language);
  formData.append('display_mode', 'hinglish');

  const res = await api.post('/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });

  return res.data as { job_id: string; project_id: string; status: string; message: string };
}

export function getLegacyDownloadUrl(renderId: string) {
  return `${API_BASE}/download/${renderId}`;
}
