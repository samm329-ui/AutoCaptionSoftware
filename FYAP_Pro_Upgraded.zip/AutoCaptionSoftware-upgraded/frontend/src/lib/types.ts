export interface Word {
  text: string;
  start: number;
  end: number;
  lang?: string;
  score?: number;
  original?: string;
}

export interface Caption {
  id: string;
  index: number;
  start: number;
  end: number;
  text: string;
  words: Word[];
  style: string;
  animation: string;
  position: { x: number; y: number };
  editable: boolean;
  confidence: number;
  emphasis: Array<Record<string, unknown>>;
}

export interface Timeline {
  id: string;
  source_file: string;
  duration: number;
  language: string;
  captions: Caption[];
  created_at: number;
  updated_at: number;
}

export interface ProjectSettings {
  caption_style: string;
  animation: string;
  font: string;
  theme: string;
}

export interface Asset {
  id: string;
  name: string;
  safe_name: string;
  role: string;
  kind: 'video' | 'audio' | 'image' | 'unknown';
  mime_type: string;
  path: string;
  url: string;
  size: number;
  duration: number;
  width: number;
  height: number;
  fps: number;
  created_at: number;
}

export interface ProjectSummary {
  id: string;
  name: string;
  description: string;
  language: string;
  display_mode: string;
  status: string;
  progress: number;
  step: string;
  created_at: number;
  updated_at: number;
  media_count: number;
  active_asset_id: string | null;
  active_asset?: Asset | null;
}

export interface ProjectDetail extends ProjectSummary {
  assets: Asset[];
  timeline: Timeline | null;
  canonical_transcript?: {
    words: Word[];
    language: string;
    duration: number;
  } | null;
  settings: ProjectSettings;
}

export interface CreateProjectPayload {
  name: string;
  description?: string;
  language?: string;
  display_mode?: string;
}

export interface UpdateProjectPayload {
  name?: string;
  description?: string;
  language?: string;
  display_mode?: string;
  active_asset_id?: string | null;
  status?: string;
  step?: string;
}

export interface GenerateCaptionsPayload {
  asset_id?: string | null;
  language?: string;
  display_mode?: string;
}

export interface UpdateCaptionPayload {
  text?: string;
  start?: number;
  end?: number;
  style?: string;
  animation?: string;
  position?: { x: number; y: number };
  emphasis?: Array<Record<string, unknown>>;
}

export interface ExportPayload {
  format: 'srt' | 'vtt' | 'ass' | 'mp4' | 'json';
  style?: string;
  animation?: string;
}

export interface ExportJob {
  id: string;
  project_id: string;
  format: string;
  style: string;
  animation: string;
  status: string;
  progress: number;
  step: string;
  output_path?: string;
  mime_type?: string;
  download_url?: string;
  error?: string;
  created_at: number;
  updated_at?: number;
}

export interface ApiListResponse<T> {
  [key: string]: T[];
}
