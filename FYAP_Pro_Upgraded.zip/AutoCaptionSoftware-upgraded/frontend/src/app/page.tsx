"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import {
  checkHealth,
  createProject,
  deleteCaption,
  deleteProject,
  exportProject,
  generateCaptions,
  getAssetUrl,
  getExport,
  getProject,
  getProjects,
  getTimeline,
  getDownloadUrl,
  listStyles,
  updateCaption,
  uploadAsset,
} from '@/lib/api';
import type {
  Asset,
  Caption,
  ExportJob,
  ProjectDetail,
  ProjectSummary,
  UpdateCaptionPayload,
} from '@/lib/types';

const TOOL_LABELS = [
  { id: 'select', label: 'Select' },
  { id: 'razor', label: 'Razor' },
  { id: 'trim', label: 'Trim' },
  { id: 'ripple', label: 'Ripple' },
  { id: 'rolling', label: 'Rolling' },
  { id: 'slip', label: 'Slip' },
  { id: 'slide', label: 'Slide' },
  { id: 'hand', label: 'Hand' },
  { id: 'zoom', label: 'Zoom' },
  { id: 'marker', label: 'Marker' },
  { id: 'caption', label: 'Caption' },
  { id: 'transform', label: 'Transform' },
] as const;

const PANEL_TABS = [
  { id: 'edit', label: 'Edit' },
  { id: 'captions', label: 'Captions' },
  { id: 'animation', label: 'Animation' },
  { id: 'export', label: 'Export' },
] as const;

const CAPTION_ANIMATIONS = [
  { id: 'pop_in', label: 'Pop In' },
  { id: 'fade', label: 'Fade' },
  { id: 'slide_up', label: 'Slide Up' },
  { id: 'bounce', label: 'Bounce' },
  { id: 'typewriter', label: 'Typewriter' },
  { id: 'karaoke', label: 'Karaoke' },
  { id: 'shake', label: 'Shake' },
  { id: 'scale_pulse', label: 'Scale Pulse' },
] as const;

const EXPORT_FORMATS = [
  { id: 'srt', label: 'SRT' },
  { id: 'vtt', label: 'VTT' },
  { id: 'ass', label: 'ASS' },
  { id: 'mp4', label: 'MP4 Burn-in' },
  { id: 'json', label: 'Project JSON' },
] as const;

const LANGUAGE_OPTIONS = [
  { id: 'auto', label: 'Auto Detect' },
  { id: 'en', label: 'English' },
  { id: 'hi', label: 'Hindi' },
  { id: 'hinglish', label: 'Hinglish' },
] as const;

const DISPLAY_OPTIONS = [
  { id: 'hinglish', label: 'Hinglish' },
  { id: 'english', label: 'English' },
] as const;

type WorkspaceMode = 'edit' | 'captions' | 'animation' | 'export';
type ToolKey = (typeof TOOL_LABELS)[number]['id'];
type ExportKey = (typeof EXPORT_FORMATS)[number]['id'];
type LanguageKey = (typeof LANGUAGE_OPTIONS)[number]['id'];
type DisplayKey = (typeof DISPLAY_OPTIONS)[number]['id'];
type ThemeKey = 'default' | 'bold' | 'gold' | 'fire';

const API_BASE = process.env.NEXT_PUBLIC_AI_SERVER_URL || 'http://localhost:8000';

function formatTime(seconds = 0) {
  if (!Number.isFinite(seconds)) return '00:00';
  const s = Math.max(0, seconds);
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = Math.floor(s % 60);
  if (hrs > 0) {
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function formatBytes(bytes = 0) {
  if (bytes >= 1e9) return `${(bytes / 1e9).toFixed(1)} GB`;
  if (bytes >= 1e6) return `${(bytes / 1e6).toFixed(1)} MB`;
  if (bytes >= 1e3) return `${(bytes / 1e3).toFixed(1)} KB`;
  return `${bytes} B`;
}

function classNames(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(' ');
}

function Panel({
  title,
  subtitle,
  children,
  className,
  rightAction,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
  rightAction?: React.ReactNode;
}) {
  return (
    <section className={classNames('glass-panel-dense flex flex-col overflow-hidden', className)}>
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-3">
        <div>
          <h3 className="text-sm font-semibold tracking-tight text-on-surface">{title}</h3>
          {subtitle ? <p className="text-[11px] text-on-surface-variant mt-0.5">{subtitle}</p> : null}
        </div>
        {rightAction ? <div>{rightAction}</div> : null}
      </div>
      <div className="min-h-0 flex-1">{children}</div>
    </section>
  );
}

function PillButton({ active, children, onClick, className }: { active?: boolean; children: React.ReactNode; onClick: () => void; className?: string }) {
  return (
    <button
      onClick={onClick}
      className={classNames(
        'rounded-full border px-3 py-1.5 text-xs font-medium transition-all',
        active
          ? 'border-primary/40 bg-primary/15 text-primary shadow-glow-primary'
          : 'border-white/10 bg-white/5 text-on-surface-variant hover:bg-white/10 hover:text-on-surface',
        className,
      )}
    >
      {children}
    </button>
  );
}

function TinyLabel({ children }: { children: React.ReactNode }) {
  return <span className="text-[10px] uppercase tracking-[0.2em] text-on-surface-variant">{children}</span>;
}

function LoadingScreen({ progress }: { progress: number }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-surface-container-lowest px-6">
      <div className="w-full max-w-xl text-center">
        <h1 className="font-headline text-5xl font-bold tracking-tight text-on-surface">FYAP Pro</h1>
        <p className="mt-3 text-sm uppercase tracking-[0.28em] text-on-surface-variant">Initializing editing engine</p>
        <div className="mt-8 h-1.5 overflow-hidden rounded-full bg-white/5">
          <div className="h-full rounded-full bg-gradient-to-r from-primary-dim via-primary to-secondary transition-all duration-500" style={{ width: `${Math.min(100, Math.max(0, progress))}%` }} />
        </div>
        <div className="mt-3 flex items-center justify-between text-[11px] text-on-surface-variant">
          <span>Loading workspace</span>
          <span className="font-mono text-primary">{Math.round(progress)}%</span>
        </div>
      </div>
    </main>
  );
}

function MediaDropzone({ onFiles, busy }: { onFiles: (files: File[]) => void; busy?: boolean }) {
  const onDrop = useCallback((acceptedFiles: File[]) => onFiles(acceptedFiles), [onFiles]);
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxFiles: 6,
    disabled: busy,
    multiple: true,
    accept: {
      'video/*': ['.mp4', '.mov', '.mkv', '.webm', '.avi'],
      'audio/*': ['.mp3', '.wav', '.aac', '.m4a', '.flac', '.ogg'],
      'image/*': ['.png', '.jpg', '.jpeg', '.webp'],
    },
  });

  return (
    <div
      {...getRootProps()}
      className={classNames(
        'group flex min-h-[180px] cursor-pointer flex-col items-center justify-center rounded-2xl border border-dashed px-6 py-10 text-center transition-all',
        isDragActive ? 'border-primary bg-primary/10' : 'border-white/10 bg-white/3 hover:border-primary/40 hover:bg-white/5',
        busy && 'pointer-events-none opacity-60',
      )}
    >
      <input {...getInputProps()} />
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/6 text-2xl text-primary">
        ⬆
      </div>
      <p className="mt-4 text-sm font-semibold text-on-surface">Drop media here or click to browse</p>
      <p className="mt-1 text-xs text-on-surface-variant">Video, audio, or images for the active project</p>
    </div>
  );
}

function ProjectsPage({
  projects,
  onCreate,
  onOpen,
  onDelete,
  busy,
}: {
  projects: ProjectSummary[];
  onCreate: (payload: { name: string; description: string; language: string; display_mode: string }) => Promise<void>;
  onOpen: (projectId: string) => Promise<void>;
  onDelete: (projectId: string) => Promise<void>;
  busy: boolean;
}) {
  const [name, setName] = useState('Untitled Project');
  const [description, setDescription] = useState('');
  const [language, setLanguage] = useState<LanguageKey>('auto');
  const [displayMode, setDisplayMode] = useState<DisplayKey>('hinglish');

  return (
    <main className="min-h-screen px-6 py-8 lg:px-8">
      <div className="mx-auto flex max-w-7xl flex-col gap-6">
        <header className="flex items-center justify-between gap-4">
          <div>
            <h1 className="font-headline text-3xl font-bold tracking-tight text-on-surface">FYAP Pro</h1>
            <p className="mt-1 text-sm text-on-surface-variant">Create projects, import media, and move directly into the editing workspace.</p>
          </div>
          <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs text-on-surface-variant">
            Premiere-style project flow · AI captions · keyframes · export
          </div>
        </header>

        <div className="grid gap-6 xl:grid-cols-[1.05fr_1.45fr]">
          <Panel title="Create New Project" subtitle="Start a new edit and choose the caption language and display mode.">
            <div className="space-y-4 p-4">
              <div className="grid gap-4 md:grid-cols-2">
                <label className="space-y-2">
                  <TinyLabel>Project name</TinyLabel>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-2xl border border-white/8 bg-black/30 px-4 py-3 text-sm text-on-surface outline-none transition focus:border-primary/40"
                    placeholder="Untitled Project"
                  />
                </label>
                <label className="space-y-2">
                  <TinyLabel>Language</TinyLabel>
                  <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value as LanguageKey)}
                    className="w-full rounded-2xl border border-white/8 bg-black/30 px-4 py-3 text-sm text-on-surface outline-none transition focus:border-primary/40"
                  >
                    {LANGUAGE_OPTIONS.map((option) => (
                      <option key={option.id} value={option.id}>{option.label}</option>
                    ))}
                  </select>
                </label>
              </div>
              <label className="space-y-2">
                <TinyLabel>Description</TinyLabel>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full rounded-2xl border border-white/8 bg-black/30 px-4 py-3 text-sm text-on-surface outline-none transition focus:border-primary/40"
                  placeholder="Optional project notes, style goals, or production details"
                />
              </label>
              <div className="grid gap-4 md:grid-cols-2">
                <label className="space-y-2">
                  <TinyLabel>Display mode</TinyLabel>
                  <select
                    value={displayMode}
                    onChange={(e) => setDisplayMode(e.target.value as DisplayKey)}
                    className="w-full rounded-2xl border border-white/8 bg-black/30 px-4 py-3 text-sm text-on-surface outline-none transition focus:border-primary/40"
                  >
                    {DISPLAY_OPTIONS.map((option) => (
                      <option key={option.id} value={option.id}>{option.label}</option>
                    ))}
                  </select>
                </label>
                <div className="flex items-end">
                  <button
                    onClick={() => onCreate({ name, description, language, display_mode: displayMode })}
                    disabled={busy || !name.trim()}
                    className="btn-primary w-full disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    Create Project
                  </button>
                </div>
              </div>
            </div>
          </Panel>

          <Panel title="Recent Projects" subtitle="Open an existing project or continue editing from the last session.">
            <div className="grid gap-4 p-4 md:grid-cols-2 xl:grid-cols-3">
              {projects.length === 0 ? (
                <div className="col-span-full rounded-2xl border border-white/8 bg-black/20 p-8 text-center text-sm text-on-surface-variant">
                  No projects yet. Create one on the left and then import your media.
                </div>
              ) : (
                projects.map((project) => (
                  <div
                    key={project.id}
                    role="button"
                    tabIndex={0}
                    onClick={() => onOpen(project.id)}
                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onOpen(project.id); }}
                    className="group rounded-2xl border border-white/8 bg-black/20 p-4 text-left transition hover:border-primary/30 hover:bg-white/5"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="text-sm font-semibold text-on-surface group-hover:text-primary">{project.name}</h3>
                        <p className="mt-1 line-clamp-2 text-xs text-on-surface-variant">{project.description || 'No description added.'}</p>
                      </div>
                      <span className="rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-on-surface-variant">{project.status}</span>
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2 text-[11px] text-on-surface-variant">
                      <span>{project.media_count} assets</span>
                      <span>•</span>
                      <span>{project.display_mode}</span>
                      <span>•</span>
                      <span>{new Date(project.updated_at * 1000).toLocaleString()}</span>
                    </div>
                    <div className="mt-4 flex items-center justify-between text-[11px] uppercase tracking-[0.18em] text-on-surface-variant">
                      <span>{project.language}</span>
                      <div className="flex items-center gap-2">
                        <span>Open workspace →</span>
                        <button
                          onClick={(e) => { e.stopPropagation(); onDelete(project.id); }}
                          className="rounded-full border border-white/10 bg-white/5 px-2 py-1 text-[10px] uppercase tracking-[0.15em] text-on-surface-variant hover:text-error"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </Panel>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <InfoCard title="Project page" description="Create or open projects before importing media." />
          <InfoCard title="Import stage" description="Add audio, video, or images, or skip directly into the editor." />
          <InfoCard title="Editor workspace" description="Caption track, animation panel, keyframes, and export live together." />
        </div>
      </div>
    </main>
  );
}

function InfoCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-2xl border border-white/8 bg-white/4 p-4">
      <h3 className="text-sm font-semibold text-on-surface">{title}</h3>
      <p className="mt-1 text-xs text-on-surface-variant">{description}</p>
    </div>
  );
}

function ExportStatusCard({ exportJob }: { exportJob: ExportJob | null }) {
  if (!exportJob) return null;
  return (
    <div className="rounded-2xl border border-white/8 bg-black/20 p-4 text-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="font-semibold text-on-surface">Export {exportJob.status}</p>
          <p className="mt-1 text-xs text-on-surface-variant">{exportJob.step}</p>
        </div>
        <span className="font-mono text-primary">{exportJob.progress}%</span>
      </div>
      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-white/6">
        <div className="h-full rounded-full bg-gradient-to-r from-primary-dim via-primary to-secondary" style={{ width: `${exportJob.progress}%` }} />
      </div>
      {exportJob.download_url ? (
        <a href={getDownloadUrl(exportJob.id)} target="_blank" rel="noreferrer" className="mt-3 inline-flex text-xs font-medium text-secondary hover:underline">
          Download exported file
        </a>
      ) : null}
    </div>
  );
}

function EditorWorkspace({
  project,
  projects,
  onBack,
  onRefreshProject,
  onRefreshProjects,
}: {
  project: ProjectDetail;
  projects: ProjectSummary[];
  onBack: () => void;
  onRefreshProject: () => Promise<void>;
  onRefreshProjects: () => Promise<void>;
}) {
  const [workspaceMode, setWorkspaceMode] = useState<WorkspaceMode>('edit');
  const [tool, setTool] = useState<ToolKey>('select');
  const [selectedCaptionId, setSelectedCaptionId] = useState<string | null>(project.timeline?.captions?.[0]?.id ?? null);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(project.active_asset_id ?? project.assets?.[0]?.id ?? null);
  const [captionDraft, setCaptionDraft] = useState<Partial<Caption> | null>(null);
  const [captionLanguage, setCaptionLanguage] = useState<LanguageKey>((project.language as LanguageKey) || 'auto');
  const [displayMode, setDisplayMode] = useState<DisplayKey>((project.display_mode as DisplayKey) || 'hinglish');
  const [activeCaptionAnimation, setActiveCaptionAnimation] = useState<string>(project.settings?.animation || 'pop_in');
  const [activeTheme, setActiveTheme] = useState<ThemeKey>('default');
  const [exportFormat, setExportFormat] = useState<ExportKey>('srt');
  const [exportJob, setExportJob] = useState<ExportJob | null>(null);
  const [loadingMedia, setLoadingMedia] = useState(false);
  const [message, setMessage] = useState<string>('');
  const [sourceIn, setSourceIn] = useState(0);
  const [sourceOut, setSourceOut] = useState(project.timeline?.duration || 0);
  const [playhead, setPlayhead] = useState(0);
  const previewRef = useRef<HTMLVideoElement | null>(null);
  const sourceRef = useRef<HTMLVideoElement | null>(null);
  const activeAsset = useMemo(() => project.assets.find((asset) => asset.id === selectedAssetId) ?? project.assets[0] ?? null, [project.assets, selectedAssetId]);
  const timeline = project.timeline;
  const duration = Math.max(timeline?.duration || 0, activeAsset?.duration || 0, 1);
  const captions = timeline?.captions || [];
  const activeCaption = useMemo(
    () => captions.find((caption) => playhead >= caption.start && playhead <= caption.end) || captions.find((caption) => caption.id === selectedCaptionId) || captions[0] || null,
    [captions, playhead, selectedCaptionId],
  );

  useEffect(() => {
    setCaptionDraft(activeCaption ? { ...activeCaption } : null);
  }, [activeCaption?.id]);

  useEffect(() => {
    if (activeCaption) {
      setSelectedCaptionId(activeCaption.id);
    }
  }, [activeCaption?.id]);

  useEffect(() => {
    if (activeAsset) {
      setSelectedAssetId(activeAsset.id);
      setSourceOut(activeAsset.duration || project.timeline?.duration || 0);
    }
  }, [activeAsset?.id]);

  const uploadFiles = useCallback(
    async (files: File[]) => {
      if (!files.length) return;
      setLoadingMedia(true);
      setMessage('Uploading media...');
      for (const file of files) {
        await uploadAsset(project.id, file, 'source');
      }
      setMessage('Media imported successfully.');
      await onRefreshProject();
      await onRefreshProjects();
      setLoadingMedia(false);
    },
    [onRefreshProject, onRefreshProjects, project.id],
  );

  const selectedCaption = captions.find((caption) => caption.id === selectedCaptionId) || activeCaption || null;

  async function handleGenerateCaptions() {
    if (!project.id) return;
    setMessage('Generating captions...');
    await generateCaptions(project.id, {
      asset_id: selectedAssetId || project.active_asset_id || null,
      language: captionLanguage,
      display_mode: displayMode,
    });
    setWorkspaceMode('captions');
    await pollProjectUntilReady();
  }

  async function pollProjectUntilReady() {
    const started = Date.now();
    const interval = window.setInterval(async () => {
      try {
        const updated = await getProject(project.id);
        if (updated.status !== 'processing' && updated.status !== 'rendering' && updated.status !== 'queued') {
          clearInterval(interval);
          await onRefreshProject();
          setMessage(updated.status === 'ready' ? 'Captions are ready.' : updated.step || 'Workspace updated.');
        }
        if (Date.now() - started > 300000) {
          clearInterval(interval);
        }
      } catch {
        // keep polling until the backend becomes available again
      }
    }, 1800);
  }

  async function handleSaveCaption() {
    if (!selectedCaption || !captionDraft) return;
    const payload: UpdateCaptionPayload = {
      text: captionDraft.text,
      start: captionDraft.start,
      end: captionDraft.end,
      style: captionDraft.style,
      animation: captionDraft.animation,
      position: captionDraft.position,
      emphasis: captionDraft.emphasis,
    };
    await updateCaption(project.id, selectedCaption.id, payload);
    setMessage('Caption updated.');
    await onRefreshProject();
  }

  async function handleSplitCaption() {
    if (!selectedCaption) return;
    const splitAt = (selectedCaption.start + selectedCaption.end) / 2;
    const form = new FormData();
    form.append('split_at', String(splitAt));
    await fetch(`${API_BASE}/projects/${project.id}/captions/${selectedCaption.id}/split`, {
      method: 'POST',
      body: form,
    });
    setMessage('Caption split.');
    await onRefreshProject();
  }

  async function handleMergeCaption() {
    if (!selectedCaption) return;
    await fetch(`${API_BASE}/projects/${project.id}/captions/${selectedCaption.id}/merge-next`, { method: 'POST' });
    setMessage('Captions merged.');
    await onRefreshProject();
  }

  async function handleDeleteCaption() {
    if (!selectedCaption) return;
    await deleteCaption(project.id, selectedCaption.id);
    setSelectedCaptionId(null);
    setMessage('Caption removed.');
    await onRefreshProject();
  }

  async function handleExport() {
    const response = await exportProject(project.id, {
      format: exportFormat,
      style: activeTheme,
      animation: activeCaptionAnimation,
    });
    setMessage('Export started.');
    const started = Date.now();
    const interval = window.setInterval(async () => {
      try {
        const job = await getExport(response.export_id);
        setExportJob(job);
        if (job.status === 'completed' || job.status === 'error') {
          clearInterval(interval);
          await onRefreshProject();
        }
        if (Date.now() - started > 300000) {
          clearInterval(interval);
        }
      } catch {
        // keep polling
      }
    }, 1800);
  }

  function seekTo(time: number) {
    setPlayhead(time);
    if (previewRef.current) {
      previewRef.current.currentTime = time;
    }
    if (sourceRef.current) {
      sourceRef.current.currentTime = time;
    }
  }

  const captionTrackBlocks = captions.map((caption) => {
    const left = (caption.start / duration) * 100;
    const width = Math.max(((caption.end - caption.start) / duration) * 100, 3.2);
    return (
      <button
        key={caption.id}
        onClick={() => {
          setSelectedCaptionId(caption.id);
          seekTo(caption.start);
        }}
        className={classNames(
          'absolute top-4 h-14 rounded-xl border px-3 py-2 text-left text-[11px] leading-tight transition-all',
          selectedCaption?.id === caption.id ? 'border-primary bg-primary/15 text-on-surface shadow-glow-primary' : 'border-white/8 bg-white/5 text-on-surface-variant hover:border-white/20 hover:bg-white/8',
        )}
        style={{ left: `${left}%`, width: `${width}%` }}
      >
        <div className="font-medium text-on-surface">{caption.text}</div>
        <div className="mt-1 font-mono text-[10px] text-on-surface-variant">
          {formatTime(caption.start)} → {formatTime(caption.end)}
        </div>
      </button>
    );
  });

  return (
    <main className="flex h-screen flex-col overflow-hidden bg-surface text-on-surface">
      <header className="flex items-center justify-between gap-4 border-b border-white/6 bg-black/30 px-4 py-3 backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="rounded-full border border-white/8 bg-white/5 px-3 py-2 text-xs text-on-surface-variant hover:text-on-surface">← Projects</button>
          <div>
            <h1 className="font-headline text-lg font-semibold tracking-tight text-on-surface">FYAP Pro</h1>
            <p className="text-[11px] text-on-surface-variant">{project.name} · {project.status} · {project.step}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <PillButton active={workspaceMode === 'edit'} onClick={() => setWorkspaceMode('edit')}>Edit</PillButton>
          <PillButton active={workspaceMode === 'captions'} onClick={() => setWorkspaceMode('captions')}>Captions</PillButton>
          <PillButton active={workspaceMode === 'animation'} onClick={() => setWorkspaceMode('animation')}>Animation</PillButton>
          <PillButton active={workspaceMode === 'export'} onClick={() => setWorkspaceMode('export')}>Export</PillButton>
          <button onClick={() => setMessage('Project saved locally on update.')} className="btn-secondary">Save</button>
          <button onClick={handleGenerateCaptions} disabled={loadingMedia} className="btn-primary disabled:opacity-60">Generate Captions</button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1">
        <aside className="flex w-[64px] flex-col items-center gap-3 border-r border-white/6 bg-black/20 py-4">
          {TOOL_LABELS.map((entry) => (
            <button
              key={entry.id}
              onClick={() => setTool(entry.id)}
              className={classNames(
                'h-10 w-10 rounded-xl text-[10px] transition-all',
                tool === entry.id ? 'bg-primary/15 text-primary shadow-glow-primary' : 'bg-white/5 text-on-surface-variant hover:bg-white/8 hover:text-on-surface',
              )}
              title={entry.label}
            >
              {entry.label.slice(0, 2)}
            </button>
          ))}
        </aside>

        <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 p-4 xl:grid-cols-[340px_minmax(0,1fr)_380px]">
          <div className="flex min-h-0 flex-col gap-4">
            <Panel title="Source Monitor" subtitle="Inspect the current source asset, trim in/out points, and preview raw media.">
              <div className="flex h-full flex-col gap-4 p-4">
                {activeAsset ? (
                  <>
                    <div className="overflow-hidden rounded-2xl border border-white/8 bg-black/40">
                      {activeAsset.kind === 'video' ? (
                        <video
                          ref={sourceRef}
                          src={activeAsset.url}
                          controls
                          className="h-[190px] w-full object-contain bg-black"
                          onTimeUpdate={(e) => setPlayhead((e.target as HTMLVideoElement).currentTime)}
                        />
                      ) : activeAsset.kind === 'audio' ? (
                        <div className="flex h-[190px] items-center justify-center bg-black/40 text-center text-sm text-on-surface-variant">
                          Audio source ready for caption generation.
                        </div>
                      ) : (
                        <div className="flex h-[190px] items-center justify-center bg-black/40 text-center text-sm text-on-surface-variant">
                          Image assets can be used as cover shots or overlays.
                        </div>
                      )}
                    </div>
                    <div className="space-y-3 rounded-2xl border border-white/8 bg-black/20 p-3 text-xs text-on-surface-variant">
                      <div className="flex items-center justify-between"><span>Name</span><span className="text-on-surface">{activeAsset.name}</span></div>
                      <div className="flex items-center justify-between"><span>Type</span><span className="text-on-surface">{activeAsset.kind}</span></div>
                      <div className="flex items-center justify-between"><span>Duration</span><span className="text-on-surface">{formatTime(activeAsset.duration)}</span></div>
                      <div className="flex items-center justify-between"><span>Size</span><span className="text-on-surface">{formatBytes(activeAsset.size)}</span></div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <label className="space-y-1">
                        <TinyLabel>In point</TinyLabel>
                        <input value={sourceIn} onChange={(e) => setSourceIn(Number(e.target.value))} type="number" step="0.1" className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" />
                      </label>
                      <label className="space-y-1">
                        <TinyLabel>Out point</TinyLabel>
                        <input value={sourceOut} onChange={(e) => setSourceOut(Number(e.target.value))} type="number" step="0.1" className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" />
                      </label>
                    </div>
                    <div className="flex flex-wrap gap-2 text-xs">
                      <button className="btn-secondary px-4 py-2">Selection</button>
                      <button className="btn-secondary px-4 py-2">Razor</button>
                      <button className="btn-secondary px-4 py-2">Trim</button>
                      <button className="btn-secondary px-4 py-2">Hand</button>
                    </div>
                  </>
                ) : (
                  <MediaDropzone onFiles={uploadFiles} busy={loadingMedia} />
                )}
              </div>
            </Panel>

            <Panel title="Project Media" subtitle="Imported assets appear here and can be loaded into the workspace." rightAction={<span className="text-[10px] uppercase tracking-[0.2em] text-on-surface-variant">{project.media_count} assets</span>}>
              <div className="flex h-full flex-col gap-3 p-4">
                {project.assets.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-white/8 bg-black/20 p-5 text-center text-xs text-on-surface-variant">
                    Use the upload panel to import audio, video, or images. You can skip import and stay in the editor shell.
                  </div>
                ) : (
                  <div className="grid max-h-[220px] gap-2 overflow-y-auto pr-1">
                    {project.assets.map((asset) => (
                      <button
                        key={asset.id}
                        onClick={() => setSelectedAssetId(asset.id)}
                        className={classNames(
                          'rounded-2xl border p-3 text-left transition-all',
                          selectedAssetId === asset.id ? 'border-primary bg-primary/15' : 'border-white/8 bg-black/20 hover:border-white/20 hover:bg-white/6',
                        )}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <p className="text-sm font-medium text-on-surface">{asset.name}</p>
                            <p className="text-[11px] text-on-surface-variant">{asset.kind.toUpperCase()} · {formatBytes(asset.size)}</p>
                          </div>
                          <span className="rounded-full border border-white/8 bg-white/5 px-2 py-1 text-[10px] uppercase tracking-[0.18em] text-on-surface-variant">{asset.role}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
                <MediaDropzone onFiles={uploadFiles} busy={loadingMedia} />
              </div>
            </Panel>
          </div>

          <div className="flex min-h-0 flex-col gap-4">
            <Panel title="Preview" subtitle="Final composition view with captions, overlays, and playback state.">
              <div className="flex h-full flex-col gap-4 p-4">
                <div className="relative overflow-hidden rounded-3xl border border-white/8 bg-black">
                  {activeAsset?.kind === 'video' ? (
                    <video
                      ref={previewRef}
                      src={activeAsset.url}
                      className="h-[360px] w-full object-contain bg-black"
                      onTimeUpdate={(e) => setPlayhead((e.target as HTMLVideoElement).currentTime)}
                      onPlay={() => setMessage('Preview playing')}
                      onPause={() => setMessage('Preview paused')}
                    />
                  ) : activeAsset?.kind === 'audio' ? (
                    <div className="flex h-[360px] items-center justify-center bg-black text-center text-sm text-on-surface-variant">
                      No video preview for audio-only source. Use the source monitor and timeline to edit captions.
                    </div>
                  ) : (
                    <div className="flex h-[360px] items-center justify-center bg-black text-center text-sm text-on-surface-variant">
                      Import a video asset to activate source and preview monitors.
                    </div>
                  )}
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                  <div className="absolute inset-x-0 bottom-6 flex justify-center px-8">
                    <div className="max-w-[90%] rounded-2xl border border-white/10 bg-black/45 px-5 py-3 text-center text-lg font-semibold text-white shadow-2xl backdrop-blur-md">
                      {activeCaption?.text || 'Caption preview appears here after generation.'}
                    </div>
                  </div>
                  <div className="absolute left-4 top-4 rounded-full border border-white/10 bg-black/45 px-3 py-1 text-[10px] uppercase tracking-[0.22em] text-on-surface-variant">
                    {formatTime(playhead)} / {formatTime(duration)}
                  </div>
                </div>

                <div className="flex items-center justify-between gap-3 rounded-2xl border border-white/8 bg-black/20 p-3 text-xs text-on-surface-variant">
                  <div className="flex items-center gap-2">
                    <button onClick={() => previewRef.current?.play()} className="btn-secondary px-4 py-2">Play</button>
                    <button onClick={() => previewRef.current?.pause()} className="btn-secondary px-4 py-2">Pause</button>
                    <button onClick={() => seekTo(Math.max(0, playhead - 1))} className="btn-secondary px-4 py-2">-1s</button>
                    <button onClick={() => seekTo(playhead + 1)} className="btn-secondary px-4 py-2">+1s</button>
                  </div>
                  <div className="flex items-center gap-2">
                    <PillButton active={displayMode === 'hinglish'} onClick={() => setDisplayMode('hinglish')}>Hinglish</PillButton>
                    <PillButton active={displayMode === 'english'} onClick={() => setDisplayMode('english')}>English</PillButton>
                  </div>
                </div>
              </div>
            </Panel>

            <Panel title="Timeline" subtitle="Multiple tracks with a caption lane, playhead, and clip blocks. Click a caption to edit it." rightAction={<span className="text-[10px] uppercase tracking-[0.18em] text-on-surface-variant">{workspaceMode} mode</span>}>
              <div className="flex h-full flex-col gap-3 p-4">
                <div className="flex items-center justify-between text-[11px] text-on-surface-variant">
                  <span className="font-mono">00:00</span>
                  <div className="flex gap-2">
                    <button className="btn-secondary px-3 py-1.5 text-[11px]">Snap</button>
                    <button className="btn-secondary px-3 py-1.5 text-[11px]">Razor</button>
                    <button className="btn-secondary px-3 py-1.5 text-[11px]">Zoom</button>
                  </div>
                  <span className="font-mono">{formatTime(duration)}</span>
                </div>
                <div
                  className="relative h-[220px] overflow-hidden rounded-2xl border border-white/8 bg-black/30"
                  onClick={(e) => {
                    const rect = (e.currentTarget as HTMLDivElement).getBoundingClientRect();
                    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
                    seekTo(ratio * duration);
                  }}
                >
                  <div className="absolute inset-x-0 top-0 h-10 border-b border-white/8 bg-white/3 px-4 text-[10px] uppercase tracking-[0.22em] text-on-surface-variant">
                    Time ruler · V1 · A1 · C1
                  </div>
                  <div className="absolute inset-x-0 top-10 bottom-0 px-4 py-3">
                    <div className="relative h-full">
                      <div className="absolute left-0 right-0 top-3 h-10 rounded-xl border border-white/8 bg-white/4" />
                      <div className="absolute left-0 right-0 top-16 h-10 rounded-xl border border-white/8 bg-white/4" />
                      <div className="absolute left-0 right-0 top-29 h-14 rounded-xl border border-primary/20 bg-primary/7" />
                      {captionTrackBlocks}
                      <div className="absolute top-0 bottom-0 w-px bg-primary shadow-glow-primary" style={{ left: `${(playhead / duration) * 100}%` }} />
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 text-xs text-on-surface-variant">
                  <span className="rounded-full border border-white/8 px-3 py-1">Video Tracks</span>
                  <span className="rounded-full border border-white/8 px-3 py-1">Audio Tracks</span>
                  <span className="rounded-full border border-primary/20 px-3 py-1 text-primary">Caption Track</span>
                  <span className="rounded-full border border-white/8 px-3 py-1">Markers</span>
                  <span className="rounded-full border border-white/8 px-3 py-1">Keyframes</span>
                </div>
              </div>
            </Panel>
          </div>

          <Panel title={workspaceMode === 'captions' ? 'Caption Panel' : workspaceMode === 'animation' ? 'Caption Animation Panel' : workspaceMode === 'export' ? 'Export Panel' : 'Inspector'} subtitle="Editing tools, animation presets, keyframes, and export options live here." className="min-h-0">
            <div className="flex h-full flex-col gap-4 p-4">
              <div className="flex flex-wrap gap-2">
                {PANEL_TABS.map((tab) => (
                  <PillButton key={tab.id} active={workspaceMode === tab.id} onClick={() => setWorkspaceMode(tab.id)}>
                    {tab.label}
                  </PillButton>
                ))}
              </div>

              {workspaceMode === 'edit' ? (
                <div className="space-y-4 overflow-y-auto pr-1 text-sm">
                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <TinyLabel>Active tool</TinyLabel>
                    <p className="mt-2 text-on-surface">{TOOL_LABELS.find((entry) => entry.id === tool)?.label || 'Select'}</p>
                    <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                      <button className="btn-secondary px-3 py-2">Cut Tool</button>
                      <button className="btn-secondary px-3 py-2">Hand Tool</button>
                      <button className="btn-secondary px-3 py-2">Zoom Tool</button>
                      <button className="btn-secondary px-3 py-2">Marker Tool</button>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <TinyLabel>Project settings</TinyLabel>
                    <div className="mt-3 grid gap-3 md:grid-cols-2">
                      <label className="space-y-2">
                        <TinyLabel>Language</TinyLabel>
                        <select value={captionLanguage} onChange={(e) => setCaptionLanguage(e.target.value as LanguageKey)} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none">
                          {LANGUAGE_OPTIONS.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}
                        </select>
                      </label>
                      <label className="space-y-2">
                        <TinyLabel>Display mode</TinyLabel>
                        <select value={displayMode} onChange={(e) => setDisplayMode(e.target.value as DisplayKey)} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none">
                          {DISPLAY_OPTIONS.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}
                        </select>
                      </label>
                    </div>
                    <div className="mt-3 grid gap-2 md:grid-cols-2">
                      <label className="space-y-2"><TinyLabel>Source in</TinyLabel><input type="number" value={sourceIn} onChange={(e) => setSourceIn(Number(e.target.value))} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" /></label>
                      <label className="space-y-2"><TinyLabel>Source out</TinyLabel><input type="number" value={sourceOut} onChange={(e) => setSourceOut(Number(e.target.value))} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" /></label>
                    </div>
                  </div>
                </div>
              ) : null}

              {workspaceMode === 'captions' ? (
                <div className="min-h-0 flex-1 overflow-y-auto pr-1 text-sm">
                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <div className="flex flex-wrap gap-2">
                      {LANGUAGE_OPTIONS.map((option) => (
                        <button key={option.id} onClick={() => setCaptionLanguage(option.id)} className={classNames('rounded-full border px-3 py-1.5 text-xs', captionLanguage === option.id ? 'border-primary bg-primary/15 text-primary' : 'border-white/10 bg-white/5 text-on-surface-variant')}>
                          {option.label}
                        </button>
                      ))}
                    </div>
                    <button onClick={handleGenerateCaptions} className="btn-primary mt-4 w-full">Generate Captions (AI)</button>
                  </div>

                  <div className="mt-4 rounded-2xl border border-white/8 bg-black/20 p-4">
                    <TinyLabel>Caption list</TinyLabel>
                    <div className="mt-3 max-h-[220px] space-y-2 overflow-y-auto pr-1">
                      {captions.length === 0 ? (
                        <div className="rounded-xl border border-dashed border-white/8 px-4 py-8 text-center text-xs text-on-surface-variant">No captions yet. Generate AI captions to populate the subtitle track.</div>
                      ) : captions.map((caption) => (
                        <button
                          key={caption.id}
                          onClick={() => setSelectedCaptionId(caption.id)}
                          className={classNames('w-full rounded-xl border px-3 py-3 text-left transition-all', selectedCaption?.id === caption.id ? 'border-primary bg-primary/15' : 'border-white/8 bg-black/30 hover:border-white/20')}
                        >
                          <div className="flex items-center justify-between gap-3">
                            <span className="text-sm text-on-surface">{caption.text}</span>
                            <span className="font-mono text-[10px] text-on-surface-variant">{formatTime(caption.start)}</span>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 rounded-2xl border border-white/8 bg-black/20 p-4">
                    <TinyLabel>Caption editor</TinyLabel>
                    {captionDraft ? (
                      <div className="mt-3 space-y-3">
                        <textarea value={captionDraft.text || ''} onChange={(e) => setCaptionDraft((prev) => ({ ...prev, text: e.target.value }))} rows={4} className="w-full rounded-2xl border border-white/8 bg-black/30 px-3 py-3 text-sm text-on-surface outline-none" />
                        <div className="grid grid-cols-2 gap-3 text-xs">
                          <label className="space-y-1"><TinyLabel>Start</TinyLabel><input type="number" step="0.1" value={captionDraft.start ?? 0} onChange={(e) => setCaptionDraft((prev) => ({ ...prev, start: Number(e.target.value) }))} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" /></label>
                          <label className="space-y-1"><TinyLabel>End</TinyLabel><input type="number" step="0.1" value={captionDraft.end ?? 0} onChange={(e) => setCaptionDraft((prev) => ({ ...prev, end: Number(e.target.value) }))} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" /></label>
                          <label className="space-y-1"><TinyLabel>Font size</TinyLabel><input type="number" defaultValue={48} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" /></label>
                          <label className="space-y-1"><TinyLabel>Color</TinyLabel><input type="text" defaultValue="#ffffff" className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none" /></label>
                        </div>
                        <div className="flex flex-wrap gap-2 text-xs">
                          <button onClick={handleSaveCaption} className="btn-primary px-4 py-2">Save caption</button>
                          <button onClick={() => setCaptionDraft((prev) => ({ ...prev, style: 'bold' }))} className="btn-secondary px-4 py-2">Bold style</button>
                          <button onClick={() => setCaptionDraft((prev) => ({ ...prev, style: 'gold' }))} className="btn-secondary px-4 py-2">Gold style</button>
                          <button onClick={() => setCaptionDraft((prev) => ({ ...prev, style: 'fire' }))} className="btn-secondary px-4 py-2">Fire style</button>
                          <button onClick={handleSplitCaption} className="btn-secondary px-4 py-2">Split</button>
                          <button onClick={handleMergeCaption} className="btn-secondary px-4 py-2">Merge</button>
                          <button onClick={handleDeleteCaption} className="btn-secondary px-4 py-2">Delete</button>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-3 rounded-xl border border-dashed border-white/8 px-4 py-8 text-center text-xs text-on-surface-variant">Select a caption on the timeline to edit timing, text, and typography.</div>
                    )}
                  </div>
                </div>
              ) : null}

              {workspaceMode === 'animation' ? (
                <div className="min-h-0 flex-1 overflow-y-auto pr-1 text-sm">
                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <TinyLabel>Animation presets</TinyLabel>
                    <div className="mt-3 grid grid-cols-2 gap-3">
                      {CAPTION_ANIMATIONS.map((animation) => (
                        <button key={animation.id} onClick={() => { setActiveCaptionAnimation(animation.id); setCaptionDraft((prev) => prev ? { ...prev, animation: animation.id } : prev); }} className={classNames('rounded-2xl border p-3 text-left transition-all', activeCaptionAnimation === animation.id ? 'border-primary bg-primary/15 text-primary' : 'border-white/8 bg-black/30 hover:border-white/20')}>
                          <div className="text-sm font-medium">{animation.label}</div>
                          <div className="mt-1 text-[11px] text-on-surface-variant">Apply to active caption blocks</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 rounded-2xl border border-white/8 bg-black/20 p-4">
                    <TinyLabel>Keyframe editor</TinyLabel>
                    <div className="mt-3 grid grid-cols-2 gap-3 text-xs">
                      <button className="btn-secondary px-3 py-2">Add keyframe</button>
                      <button className="btn-secondary px-3 py-2">Delete keyframe</button>
                      <button className="btn-secondary px-3 py-2">Ease in</button>
                      <button className="btn-secondary px-3 py-2">Ease out</button>
                    </div>
                    <div className="mt-4 rounded-2xl border border-white/8 bg-black/35 p-4">
                      <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.2em] text-on-surface-variant">
                        <span>Speed graph</span>
                        <span>Value graph</span>
                      </div>
                      <div className="mt-4 h-24 rounded-xl border border-dashed border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.04),rgba(255,255,255,0.02))]" />
                    </div>
                  </div>
                </div>
              ) : null}

              {workspaceMode === 'export' ? (
                <div className="min-h-0 flex-1 overflow-y-auto pr-1 text-sm">
                  <div className="rounded-2xl border border-white/8 bg-black/20 p-4">
                    <TinyLabel>Export options</TinyLabel>
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      {EXPORT_FORMATS.map((format) => (
                        <button key={format.id} onClick={() => setExportFormat(format.id)} className={classNames('rounded-xl border px-3 py-2 text-xs', exportFormat === format.id ? 'border-primary bg-primary/15 text-primary' : 'border-white/8 bg-black/30 text-on-surface-variant')}>
                          {format.label}
                        </button>
                      ))}
                    </div>
                    <div className="mt-4 grid gap-3 md:grid-cols-2">
                      <label className="space-y-2"><TinyLabel>Theme</TinyLabel><select value={activeTheme} onChange={(e) => setActiveTheme(e.target.value as ThemeKey)} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none">{[{id:'default',label:'Default'},{id:'bold',label:'Bold'},{id:'gold',label:'Gold'},{id:'fire',label:'Fire'}].map((theme)=><option key={theme.id} value={theme.id}>{theme.label}</option>)}</select></label>
                      <label className="space-y-2"><TinyLabel>Animation</TinyLabel><select value={activeCaptionAnimation} onChange={(e) => setActiveCaptionAnimation(e.target.value)} className="w-full rounded-xl border border-white/8 bg-black/30 px-3 py-2 text-on-surface outline-none">{CAPTION_ANIMATIONS.map((animation)=><option key={animation.id} value={animation.id}>{animation.label}</option>)}</select></label>
                    </div>
                    <button onClick={handleExport} className="btn-primary mt-4 w-full">Start export</button>
                  </div>
                  <div className="mt-4"><ExportStatusCard exportJob={exportJob} /></div>
                </div>
              ) : null}

              {message ? <div className="rounded-2xl border border-white/8 bg-black/20 px-4 py-3 text-xs text-on-surface-variant">{message}</div> : null}
            </div>
          </Panel>
        </div>
      </div>

      <AnimatePresence>
        {(loadingMedia || project.status === 'processing' || project.status === 'rendering' || project.status === 'queued') ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pointer-events-none fixed inset-0 z-40 flex items-end justify-end p-6">
            <div className="rounded-2xl border border-primary/20 bg-black/70 px-4 py-3 text-sm text-on-surface shadow-2xl backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <div className="h-2.5 w-2.5 animate-pulse rounded-full bg-primary" />
                <div>
                  <p className="font-medium text-on-surface">{loadingMedia ? 'Uploading media' : project.step}</p>
                  <p className="text-[11px] text-on-surface-variant">{project.status.toUpperCase()} · {project.progress}%</p>
                </div>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </main>
  );
}

export default function Page() {
  const [loading, setLoading] = useState(true);
  const [projects, setProjects] = useState<ProjectSummary[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [project, setProject] = useState<ProjectDetail | null>(null);
  const [busy, setBusy] = useState(false);
  const [health, setHealth] = useState<unknown>(null);

  const refreshProjects = useCallback(async () => {
    const items = await getProjects();
    setProjects(items);
  }, []);

  const refreshProject = useCallback(async (projectId?: string) => {
    const id = projectId || activeProjectId;
    if (!id) return;
    const updated = await getProject(id);
    setProject(updated);
    setActiveProjectId(updated.id);
    return updated;
  }, [activeProjectId]);

  useEffect(() => {
    const bootstrap = async () => {
      const [healthData] = await Promise.all([checkHealth(), refreshProjects()]);
      setHealth(healthData);
      setTimeout(() => setLoading(false), 700);
    };
    bootstrap().catch(() => setLoading(false));
  }, [refreshProjects]);

  async function handleCreateProject(payload: { name: string; description: string; language: string; display_mode: string }) {
    setBusy(true);
    try {
      const created = await createProject(payload);
      setActiveProjectId(created.id);
      await refreshProjects();
      await refreshProject(created.id);
    } finally {
      setBusy(false);
    }
  }

  async function handleOpenProject(projectId: string) {
    setBusy(true);
    try {
      await refreshProject(projectId);
    } finally {
      setBusy(false);
    }
  }

  async function handleDeleteProject(projectId: string) {
    setBusy(true);
    try {
      await deleteProject(projectId);
      if (activeProjectId === projectId) {
        setActiveProjectId(null);
        setProject(null);
      }
      await refreshProjects();
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return <LoadingScreen progress={health ? 68 : 34} />;
  }

  if (!activeProjectId || !project) {
    return <ProjectsPage projects={projects} onCreate={handleCreateProject} onOpen={handleOpenProject} onDelete={handleDeleteProject} busy={busy} />;
  }

  return (
    <EditorWorkspace
      project={project}
      projects={projects}
      onBack={() => {
        setProject(null);
        setActiveProjectId(null);
      }}
      onRefreshProject={async () => {
        if (activeProjectId) {
          const updated = await getProject(activeProjectId);
          setProject(updated);
        }
      }}
      onRefreshProjects={refreshProjects}
    />
  );
}
