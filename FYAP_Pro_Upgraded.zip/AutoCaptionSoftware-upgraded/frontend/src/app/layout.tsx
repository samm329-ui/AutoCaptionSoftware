import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'FYAP Pro',
  description: 'A production-grade AI caption editing and video workspace.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body className="font-body bg-surface text-on-surface antialiased min-h-screen overflow-hidden">
        <div className="fixed inset-0 pointer-events-none z-0">
          <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] rounded-full bg-primary-dim/6 blur-[120px]" />
          <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-secondary/6 blur-[120px]" />
        </div>
        <div className="relative z-10">{children}</div>
      </body>
    </html>
  );
}
