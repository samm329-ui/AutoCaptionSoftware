"""
text_normalizer.py — THE ONLY PLACE TEXT IS EVER MODIFIED

Rules:
  1. This runs ONCE on every word, right after ASR output
  2. Nothing else in the pipeline is allowed to change text
  3. Output is always clean Roman/Latin characters (Hinglish)

Input:  {"text": "है", "start": 1.2, "end": 1.5, "lang": "hi"}
Output: {"text": "hai", "start": 1.2, "end": 1.5, "lang": "hi", "original": "है"}
"""

import re
from typing import List, Dict, Any

try:
    from indic_transliteration import sanscript
    from indic_transliteration.sanscript import transliterate
    INDIC_AVAILABLE = True
except ImportError:
    INDIC_AVAILABLE = False


# ─── Common Hindi/Hinglish word map ────────────────────────────────────────────
DEVANAGARI_MAP = {
    # Negation / affirmation
    "नहीं": "nahi", "नही": "nahi", "हाँ": "haan", "हां": "haan", "ना": "na",
    # Questions
    "क्या": "kya", "कैसे": "kaise", "कहाँ": "kahan", "कहां": "kahan",
    "क्यों": "kyun", "क्यूं": "kyun", "कब": "kab", "कौन": "kaun",
    # Verbs – to be / have
    "है": "hai", "हैं": "hain", "था": "tha", "थी": "thi", "थे": "the",
    "होगा": "hoga", "होगी": "hogi", "होंगे": "honge", "हो": "ho",
    "हूँ": "hoon", "हूं": "hoon",
    # Common verbs
    "करना": "karna", "करता": "karta", "करती": "karti", "करते": "karte",
    "करूँगा": "karunga", "करूंगा": "karunga", "करेगा": "karega",
    "होना": "hona", "जाना": "jaana", "आना": "aana", "देना": "dena",
    "लेना": "lena", "कहना": "kehna", "बोलना": "bolna", "देखना": "dekhna",
    "सुनना": "sunna", "समझना": "samajhna", "बताना": "batana",
    "रुकना": "rukna", "चलना": "chalna", "जाओ": "jao", "आओ": "aao",
    "देखो": "dekho", "सुनो": "suno", "बताओ": "batao", "समझो": "samjho",
    "चलो": "chalo", "रुको": "ruko",
    # Adverbs / intensifiers
    "बहुत": "bahut", "एकदम": "ekdam", "बिल्कुल": "bilkul",
    "काफी": "kaafi", "ज्यादा": "zyada", "कम": "kam", "थोड़ा": "thoda",
    "थोड़ी": "thodi", "जरा": "zara", "अभी": "abhi", "सीधे": "seedhe",
    # Conjunctions / connectors
    "और": "aur", "या": "ya", "पर": "par", "लेकिन": "lekin",
    "मगर": "magar", "फिर": "phir", "तो": "toh", "अगर": "agar",
    "क्योंकि": "kyunki", "इसलिए": "isliye", "तभी": "tabhi",
    "जब": "jab", "तब": "tab", "जैसे": "jaise", "वैसे": "waise",
    # Adjectives
    "अच्छा": "achha", "अच्छी": "achhi", "अच्छे": "achhe",
    "बुरा": "bura", "बड़ा": "bada", "बड़ी": "badi", "बड़े": "bade",
    "छोटा": "chhota", "नया": "naya", "पुराना": "purana",
    "सही": "sahi", "गलत": "galat", "ठीक": "theek",
    "पूरा": "poora", "असली": "asli", "झूठा": "jhoota",
    # Pronouns
    "मैं": "main", "तुम": "tum", "आप": "aap", "हम": "hum",
    "वो": "wo", "यह": "yeh", "वह": "woh", "ये": "ye", "वे": "ve",
    "मेरा": "mera", "मेरी": "meri", "मेरे": "mere",
    "तुम्हारा": "tumhara", "तुम्हारी": "tumhari",
    "हमारा": "hamara", "हमारी": "hamari",
    "अपना": "apna", "अपनी": "apni", "किसी": "kisi",
    "कोई": "koi", "कुछ": "kuch", "सब": "sab", "सभी": "sabhi",
    # Time / place
    "आज": "aaj", "कल": "kal", "परसों": "parso", "अभी": "abhi",
    "यहाँ": "yahan", "यहां": "yahan", "वहाँ": "wahan", "वहां": "wahan",
    "जहाँ": "jahan", "जहां": "jahan",
    # Common nouns / business terms
    "पैसा": "paisa", "पैसे": "paise", "काम": "kaam", "समय": "samay",
    "बात": "baat", "बातें": "baatein", "चीज": "cheez", "चीजें": "cheejen",
    "लोग": "log", "दोस्त": "dost", "भाई": "bhai", "यार": "yaar",
    "दिन": "din", "साल": "saal", "घर": "ghar",
    "बिजनेस": "business", "मार्जिन": "margin", "नंबर": "number",
    "सेल्स": "sales", "प्राइस": "price", "प्रॉफिट": "profit",
    "बजट": "budget", "स्ट्रैटेजी": "strategy", "मार्केट": "market",
    # Fillers / common spoken words
    "मतलब": "matlab", "असल": "asal", "दरअसल": "darasal",
    "सच": "sach", "सच्ची": "sachchi", "झूठ": "jhooth",
    "पता": "pata", "नाम": "naam", "काम": "kaam",
    "देखिए": "dekhiye", "सुनिए": "suniye", "जानिए": "janiye",
    "जानते": "jaante", "जानती": "jaanti", "जानता": "jaanta",
    "नहीं तो": "nahi toh", "हाँ तो": "haan toh",
}

# ─── Basic Urdu character map (for when indic_transliteration not available) ───
URDU_CHAR_MAP = {
    'ا': 'a', 'آ': 'aa', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ٹ': 't',
    'ث': 's', 'ج': 'j', 'چ': 'ch', 'ح': 'h', 'خ': 'kh', 'د': 'd',
    'ڈ': 'd', 'ذ': 'z', 'ر': 'r', 'ڑ': 'r', 'ز': 'z', 'ژ': 'zh',
    'س': 's', 'ش': 'sh', 'ص': 's', 'ض': 'z', 'ط': 't', 'ظ': 'z',
    'ع': 'a', 'غ': 'gh', 'ف': 'f', 'ق': 'q', 'ک': 'k', 'گ': 'g',
    'ل': 'l', 'م': 'm', 'ن': 'n', 'ں': 'n', 'و': 'w', 'ہ': 'h',
    'ھ': 'h', 'ی': 'y', 'ے': 'e', 'ئ': 'y', 'ء': 'a', 'ؤ': 'o',
    'ة': 'h', 'ۃ': 'h', '\u0651': '', '\u0652': '', '\u064e': 'a',
    '\u064f': 'u', '\u0650': 'i', '\u0670': 'a',
}

# ─── Devanagari character map ──────────────────────────────────────────────────
DEVANAGARI_CHAR_MAP = {
    'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'ng',
    'च': 'ch', 'छ': 'chh', 'ज': 'j', 'झ': 'jh', 'ञ': 'n',
    'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh', 'ण': 'n',
    'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n',
    'प': 'p', 'फ': 'ph', 'ब': 'b', 'भ': 'bh', 'म': 'm',
    'य': 'y', 'र': 'r', 'ल': 'l', 'व': 'v', 'ळ': 'l',
    'श': 'sh', 'ष': 'sh', 'स': 's', 'ह': 'h',
    'ा': 'aa', 'ि': 'i', 'ी': 'ee', 'ु': 'u', 'ू': 'oo',
    'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au',
    'ं': 'n', 'ँ': 'n', 'ः': 'h', '्': '',
    'ऽ': '', '।': '.', '॥': '.',
    'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'ee',
    'उ': 'u', 'ऊ': 'oo', 'ए': 'e', 'ऐ': 'ai',
    'ओ': 'o', 'औ': 'au', 'ऋ': 'ri',
    # Numerals
    '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
    '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
}


def _has_devanagari(text: str) -> bool:
    return any(0x0900 <= ord(c) <= 0x097F for c in text)


def _has_arabic_urdu(text: str) -> bool:
    return any(0x0600 <= ord(c) <= 0x06FF for c in text)


def _is_roman(text: str) -> bool:
    alpha = [c for c in text if c.isalpha()]
    if not alpha:
        return True  # no alpha chars → treat as roman (numbers, punctuation)
    latin = sum(1 for c in alpha if ord(c) < 128)
    return latin / len(alpha) >= 0.85


def _transliterate_devanagari_word(word: str) -> str:
    """Try library first, fall back to char map."""
    clean = re.sub(r'[^\u0900-\u097F]', '', word)
    if not clean:
        return word

    # Check common map first (most accurate)
    if clean in DEVANAGARI_MAP:
        return DEVANAGARI_MAP[clean]

    # Try indic_transliteration library
    if INDIC_AVAILABLE:
        try:
            result = transliterate(clean, sanscript.DEVANAGARI, sanscript.ITRANS)
            # Convert ITRANS to natural Hinglish spelling
            result = result.replace('aa', 'a').replace('ii', 'i').replace('uu', 'u')
            result = result.replace('sh', 'sh').replace('N', 'n').replace('H', 'h')
            return result
        except Exception:
            pass

    # Fall back to char map
    result = []
    for char in clean:
        result.append(DEVANAGARI_CHAR_MAP.get(char, char))
    return ''.join(result)


def _transliterate_urdu_word(word: str) -> str:
    """Convert Urdu word to Hinglish using char map."""
    result = []
    for char in word:
        result.append(URDU_CHAR_MAP.get(char, ''))
    joined = ''.join(result).strip()
    return joined if joined else word


def normalize_word(word_text: str) -> str:
    """
    Normalize a single word token.
    Input: any script (Devanagari, Urdu/Arabic, Roman, mixed)
    Output: clean Roman/Latin Hinglish string
    """
    if not word_text:
        return word_text

    text = word_text.strip()

    # Already Roman → return as-is
    if _is_roman(text):
        return text

    # Mixed word (e.g. "call करूँगा")
    # Split into script chunks and process each
    if _has_devanagari(text) and any(ord(c) < 128 for c in text if c.isalpha()):
        parts = re.split(r'([\u0900-\u097F]+)', text)
        result = []
        for part in parts:
            if _has_devanagari(part):
                result.append(_transliterate_devanagari_word(part))
            else:
                result.append(part)
        return ''.join(result).strip()

    # Pure Devanagari
    if _has_devanagari(text):
        # Strip punctuation, convert, reattach
        punct_match = re.search(r'[^\u0900-\u097F\s]+$', text)
        punct = punct_match.group() if punct_match else ''
        clean = re.sub(r'[^\u0900-\u097F]', '', text)
        converted = _transliterate_devanagari_word(clean)
        return converted + punct

    # Urdu / Arabic script
    if _has_arabic_urdu(text):
        punct_match = re.search(r'[^\u0600-\u06FF\s]+$', text)
        punct = punct_match.group() if punct_match else ''
        clean = re.sub(r'[^\u0600-\u06FF]', '', text)
        converted = _transliterate_urdu_word(clean)
        return (converted + punct).strip() if converted else ''

    # Unknown script → strip non-ASCII and return
    cleaned = re.sub(r'[^\x00-\x7F\s]', '', text).strip()
    return cleaned if cleaned else ''


def normalize_words(words: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    THE ONE NORMALIZATION PASS.
    Run this once on canonical_words from TranscriptionEngine.
    After this, text must never be modified again.

    Each word dict: {"text": str, "start": float, "end": float, ...}
    Returns same structure with "text" normalized to clean Hinglish.
    """
    normalized = []
    for word in words:
        original = word.get("text", "")
        converted = normalize_word(original)

        new_word = word.copy()
        new_word["text"] = converted
        new_word["original"] = original   # keep original for debugging

        # Only add word if it produced some output
        if converted:
            normalized.append(new_word)
        else:
            # Completely non-convertible → skip the word
            print(f"[TextNormalizer] Skipped non-convertible token: {repr(original)}")

    return normalized


def detect_emphasis(text: str) -> List[Dict[str, Any]]:
    """
    Detect words that should be visually emphasized.
    Runs on the already-normalized (Roman) text.
    """
    patterns = [
        (r'\b(nahi|never|no|not|mat|bilkul\s+nahi)\b', 'negation'),
        (r'\b(bahut|very|really|ekdam|bilkul|kaafi|zyada|too|so)\b', 'intensifier'),
        (r'\b\d+\b', 'number'),
        (r'\b(rupees?|rs\.?|₹|dollars?|percent|%)\b', 'money'),
        (r'\b(kya|kaise|kab|kahan|kyun|kaun|what|why|how|when|where|who)\b', 'question'),
        (r'\b(kyunki|because|isliye|so|lekin|but|phir|then|aur|or)\b', 'connector'),
        (r'\b[A-Z]{2,}\b', 'acronym'),
        (r'\b(business|margin|profit|sales|strategy|market|customer|revenue|views|real)\b', 'keyword'),
    ]

    emphasis = []
    text_lower = text.lower()
    for pattern, etype in patterns:
        for match in re.finditer(pattern, text_lower, re.IGNORECASE):
            emphasis.append({
                "word": text[match.start():match.end()],
                "start_char": match.start(),
                "end_char": match.end(),
                "type": etype
            })

    return emphasis
