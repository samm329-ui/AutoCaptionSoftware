from __future__ import annotations

"""
FYAP Pro backend.

Keeps the caption engine intact and adds the missing product shell:
projects, assets, timeline persistence, caption editing, animation metadata,
preview, and export endpoints.
"""

import copy
import json
import mimetypes
import os
import shutil
import subprocess
import threading
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from dotenv import load_dotenv
from fastapi import BackgroundTasks, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field

from ass_renderer import ASSRenderer
from display_processor import HinglishProcessor
from preview_renderer import PreviewRenderer
from smart_segmentation import SmartSegmenter
from text_normalizer import normalize_words
from timeline_model import Caption, Timeline, TimelineEditor
from transcription_engine import TranscriptionEngine

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "storage"
PROJECTS_DIR = STORAGE_DIR / "projects"
MEDIA_DIR = STORAGE_DIR / "media"
AUDIO_DIR = STORAGE_DIR / "audio"
EXPORTS_DIR = STORAGE_DIR / "exports"
PREVIEWS_DIR = STORAGE_DIR / "previews"
FONTS_DIR = BASE_DIR / "fonts"

for folder in [STORAGE_DIR, PROJECTS_DIR, MEDIA_DIR, AUDIO_DIR, EXPORTS_DIR, PREVIEWS_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)


def now() -> float:
    return time.time()


def make_safe_name(name: str) -> str:
    clean = [ch if ch.isalnum() or ch in {".", "_", "-", " "} else "_" for ch in name.strip()]
    result = "".join(clean).strip()
    return result or "untitled"


def parse_fps(rate: str) -> float:
    if not rate:
        return 0.0
    if "/" in rate:
        num, den = rate.split("/", 1)
        try:
            den_value = float(den)
            if den_value == 0:
                return 0.0
            return float(num) / den_value
        except Exception:
            return 0.0
    try:
        return float(rate)
    except Exception:
        return 0.0


def ffprobe(path: str) -> Dict[str, Any]:
    cmd = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration:stream=index,codec_type,codec_name,width,height,r_frame_rate",
        "-of",
        "json",
        path,
    ]
    try:
        out = subprocess.check_output(cmd, text=True)
        return json.loads(out)
    except Exception:
        return {}


def media_kind(file_name: str, mime_type: str | None = None) -> str:
    mime_type = mime_type or mimetypes.guess_type(file_name)[0] or ""
    if mime_type.startswith("video/"):
        return "video"
    if mime_type.startswith("audio/"):
        return "audio"
    if mime_type.startswith("image/"):
        return "image"
    ext = Path(file_name).suffix.lower()
    if ext in {".mp4", ".mov", ".mkv", ".webm", ".avi", ".mxf", ".prores"}:
        return "video"
    if ext in {".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg"}:
        return "audio"
    if ext in {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff"}:
        return "image"
    return "unknown"


class Store:
    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.RLock()
        self.data: Dict[str, Any] = {"projects": {}, "exports": {}, "jobs": {}}
        self.load()

    def load(self) -> None:
        if self.path.exists():
            try:
                with self.path.open("r", encoding="utf-8") as f:
                    payload = json.load(f)
                self.data["projects"] = payload.get("projects", {})
                self.data["exports"] = payload.get("exports", {})
                self.data["jobs"] = payload.get("jobs", {})
            except Exception:
                self.data = {"projects": {}, "exports": {}, "jobs": {}}
        self.save()

    def save(self) -> None:
        with self.lock:
            tmp = self.path.with_suffix(".tmp")
            with tmp.open("w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            tmp.replace(self.path)

    def get_project(self, project_id: str) -> Dict[str, Any] | None:
        return self.data["projects"].get(project_id)

    def set_project(self, project_id: str, payload: Dict[str, Any]) -> None:
        self.data["projects"][project_id] = payload
        self.save()

    def update_project(self, project_id: str, **changes: Any) -> Dict[str, Any]:
        if project_id not in self.data["projects"]:
            raise KeyError(project_id)
        self.data["projects"][project_id].update(changes)
        self.data["projects"][project_id]["updated_at"] = now()
        self.save()
        return self.data["projects"][project_id]

    def get_export(self, export_id: str) -> Dict[str, Any] | None:
        return self.data["exports"].get(export_id)

    def set_export(self, export_id: str, payload: Dict[str, Any]) -> None:
        self.data["exports"][export_id] = payload
        self.save()

    def list_projects(self) -> List[Dict[str, Any]]:
        projects = list(self.data["projects"].values())
        return sorted(projects, key=lambda p: p.get("updated_at", 0), reverse=True)


store = Store(STORAGE_DIR / "database.json")

transcription_engine: Optional[TranscriptionEngine] = None
segmenter: Optional[SmartSegmenter] = None
display_processor: Optional[HinglishProcessor] = None
preview_renderer: Optional[PreviewRenderer] = None
ass_renderer: Optional[ASSRenderer] = None


class ProjectCreateRequest(BaseModel):
    name: str = "Untitled Project"
    description: str = ""
    language: str = "auto"
    display_mode: str = "hinglish"


class ProjectUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    language: Optional[str] = None
    display_mode: Optional[str] = None
    active_asset_id: Optional[str] = None
    status: Optional[str] = None
    step: Optional[str] = None


class GenerateCaptionsRequest(BaseModel):
    asset_id: Optional[str] = None
    language: str = "auto"
    display_mode: str = "hinglish"


class CaptionUpdateRequest(BaseModel):
    text: Optional[str] = None
    start: Optional[float] = None
    end: Optional[float] = None
    style: Optional[str] = None
    animation: Optional[str] = None
    position: Optional[Dict[str, float]] = None
    emphasis: Optional[List[Dict[str, Any]]] = None


class ExportRequest(BaseModel):
    format: Literal["srt", "vtt", "ass", "mp4", "json"] = "srt"
    style: str = "default"
    animation: str = "pop_in"


@asynccontextmanager
async def lifespan(app: FastAPI):
    global transcription_engine, segmenter, display_processor, preview_renderer, ass_renderer

    transcription_engine = TranscriptionEngine(model_size=os.environ.get("WHISPER_MODEL", "base"))
    segmenter = SmartSegmenter()
    display_processor = HinglishProcessor()
    preview_renderer = PreviewRenderer()
    ass_renderer = ASSRenderer(str(FONTS_DIR))

    yield

    store.save()


app = FastAPI(
    title="FYAP Pro",
    version="4.0.0",
    description="Project-based captioning editor with timeline, animation, and export shell.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _ensure_project_defaults(project_id: str, name: str, description: str, language: str, display_mode: str) -> Dict[str, Any]:
    return {
        "id": project_id,
        "name": name,
        "description": description,
        "language": language,
        "display_mode": display_mode,
        "status": "idle",
        "progress": 0,
        "step": "Project ready",
        "created_at": now(),
        "updated_at": now(),
        "assets": [],
        "active_asset_id": None,
        "timeline": None,
        "canonical_transcript": None,
        "settings": {
            "caption_style": "default",
            "animation": "pop_in",
            "font": "Inter",
            "theme": "dark",
        },
    }


def _project_summary(project: Dict[str, Any]) -> Dict[str, Any]:
    assets = project.get("assets", [])
    active_asset = None
    active_id = project.get("active_asset_id")
    for asset in assets:
        if asset.get("id") == active_id:
            active_asset = asset
            break
    return {
        "id": project.get("id"),
        "name": project.get("name"),
        "description": project.get("description", ""),
        "language": project.get("language", "auto"),
        "display_mode": project.get("display_mode", "hinglish"),
        "status": project.get("status", "idle"),
        "progress": project.get("progress", 0),
        "step": project.get("step", ""),
        "created_at": project.get("created_at", now()),
        "updated_at": project.get("updated_at", now()),
        "media_count": len(assets),
        "active_asset_id": active_id,
        "active_asset": active_asset,
    }


def _public_asset(project_id: str, asset: Dict[str, Any]) -> Dict[str, Any]:
    cloned = copy.deepcopy(asset)
    cloned["url"] = f"/projects/{project_id}/assets/{asset['id']}/file"
    return cloned


def _project_detail(project: Dict[str, Any]) -> Dict[str, Any]:
    payload = copy.deepcopy(project)
    project_id = payload["id"]
    payload["assets"] = [_public_asset(project_id, a) for a in payload.get("assets", [])]
    if payload.get("timeline"):
        payload["timeline"] = copy.deepcopy(payload["timeline"])
    return payload


def _find_project_or_404(project_id: str) -> Dict[str, Any]:
    project = store.get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


def _find_asset_or_404(project: Dict[str, Any], asset_id: Optional[str]) -> Dict[str, Any]:
    assets = project.get("assets", [])
    if asset_id:
        for asset in assets:
            if asset.get("id") == asset_id:
                return asset
    active_id = project.get("active_asset_id")
    if active_id:
        for asset in assets:
            if asset.get("id") == active_id:
                return asset
    for asset in assets:
        if asset.get("kind") in {"video", "audio"}:
            return asset
    raise HTTPException(status_code=400, detail="No media asset available for caption generation")


def _set_project_state(project_id: str, status: str, progress: int, step: str) -> None:
    with store.lock:
        project = _find_project_or_404(project_id)
        project["status"] = status
        project["progress"] = progress
        project["step"] = step
        project["updated_at"] = now()
        store.save()


def _write_text_file(path: Path, content: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return str(path)


def _fmt_srt(seconds: float) -> str:
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    if ms >= 1000:
        secs += 1
        ms -= 1000
    if secs >= 60:
        mins += 1
        secs -= 60
    if mins >= 60:
        hrs += 1
        mins -= 60
    return f"{hrs:02d}:{mins:02d}:{secs:02d},{ms:03d}"


def _fmt_vtt(seconds: float) -> str:
    hrs = int(seconds // 3600)
    mins = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    if ms >= 1000:
        secs += 1
        ms -= 1000
    return f"{hrs:02d}:{mins:02d}:{secs:02d}.{ms:03d}"


def _segments_to_srt(captions: List[Dict[str, Any]]) -> str:
    lines: List[str] = []
    for index, cap in enumerate(captions, 1):
        lines.extend([
            str(index),
            f"{_fmt_srt(float(cap.get('start', 0)))} --> {_fmt_srt(float(cap.get('end', 0)))}",
            cap.get("text", ""),
            "",
        ])
    return "\n".join(lines)


def _segments_to_vtt(captions: List[Dict[str, Any]]) -> str:
    lines: List[str] = ["WEBVTT", ""]
    for cap in captions:
        lines.extend([
            f"{_fmt_vtt(float(cap.get('start', 0)))} --> {_fmt_vtt(float(cap.get('end', 0)))}",
            cap.get("text", ""),
            "",
        ])
    return "\n".join(lines)


def _segments_to_project_json(project_id: str, project: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "version": "4.0.0",
        "exported_at": now(),
        "project_id": project_id,
        "project": _project_detail(project),
    }


def _save_project(project_id: str, project: Dict[str, Any]) -> None:
    store.set_project(project_id, project)


def _build_timeline(project: Dict[str, Any], source_path: str, duration: float, language: str, captions: List[Caption]) -> Timeline:
    return Timeline(
        id=project["id"],
        source_file=source_path,
        duration=duration,
        language=language or "mixed",
        captions=captions,
        created_at=project.get("created_at", now()),
        updated_at=now(),
    )


def _process_project_captions(project_id: str, asset_id: Optional[str], language: str, display_mode: str) -> None:
    if not transcription_engine or not segmenter or not display_processor or not ass_renderer:
        raise RuntimeError("Engines are not initialized")

    _set_project_state(project_id, "processing", 10, "Preparing media...")
    project = _find_project_or_404(project_id)
    asset = _find_asset_or_404(project, asset_id)

    source_path = asset.get("path", "")
    if not source_path or not os.path.exists(source_path):
        raise HTTPException(status_code=400, detail="Media file not found")
    if asset.get("kind") == "image":
        raise HTTPException(status_code=400, detail="Images do not contain audio for caption generation")

    _set_project_state(project_id, "processing", 20, "Normalizing audio...")
    normalized_audio = transcription_engine.process_media(source_path, str(AUDIO_DIR / project_id))

    _set_project_state(project_id, "processing", 40, "Transcribing speech...")
    requested_language = None if language in {"", "auto", "Auto", "AUTO"} else language
    transcript = transcription_engine.transcribe(normalized_audio, language=requested_language)
    raw_words = transcript.get("words", [])
    detected_language = transcript.get("language", project.get("language", "auto"))
    duration = float(transcript.get("duration", 0) or 0)

    _set_project_state(project_id, "processing", 55, "Normalizing transcript...")
    canonical_words = normalize_words(raw_words)
    project["canonical_transcript"] = {
        "words": canonical_words,
        "language": detected_language,
        "duration": duration,
    }

    _set_project_state(project_id, "processing", 70, "Building timeline captions...")
    segments = segmenter.segment(
        canonical_words,
        max_line_width=42,
        min_pause_gap=0.3,
        max_reading_speed=25.0,
    )

    captions: List[Caption] = []
    for index, seg in enumerate(segments):
        raw_text = seg.get("text", "")
        display_text = display_processor.process_text(raw_text)
        emphasis = display_processor.detect_emphasis(display_text)
        cap = Caption(
            id=f"cap_{index:03d}",
            index=index,
            start=float(seg.get("start", 0)),
            end=float(seg.get("end", 0)),
            text=display_text,
            words=seg.get("words", []),
            style=project.get("settings", {}).get("caption_style", "default"),
            animation=project.get("settings", {}).get("animation", "pop_in"),
            position={"x": 0.5, "y": 0.82},
            editable=True,
            confidence=float(seg.get("confidence", 1.0)),
            emphasis=emphasis,
        )
        captions.append(cap)

    timeline = _build_timeline(project, source_path, duration, detected_language, captions)
    timeline_dict = timeline.to_dict()

    _set_project_state(project_id, "ready", 95, "Finalizing editor state...")
    project["timeline"] = timeline_dict
    project["display_mode"] = display_mode
    project["language"] = detected_language
    project["status"] = "ready"
    project["progress"] = 100
    project["step"] = "Captions ready"
    project["active_asset_id"] = asset.get("id")
    project["updated_at"] = now()
    _save_project(project_id, project)

    store.data["jobs"][project_id] = {
        "id": project_id,
        "status": "completed",
        "type": "caption_generation",
        "project_id": project_id,
        "progress": 100,
        "step": "Captions ready",
        "created_at": project.get("created_at", now()),
        "updated_at": now(),
    }
    store.save()


def _run_export_job(export_id: str, project_id: str, fmt: str, style: str, animation: str) -> None:
    try:
        project = _find_project_or_404(project_id)
        timeline = project.get("timeline")
        if not timeline:
            raise HTTPException(status_code=400, detail="Timeline not available")
        video_path = _find_asset_or_404(project, project.get("active_asset_id")).get("path", "")
        if not video_path or not os.path.exists(video_path):
            raise HTTPException(status_code=400, detail="Source media missing")

        export_dir = EXPORTS_DIR / project_id
        export_dir.mkdir(parents=True, exist_ok=True)
        captions = timeline.get("captions", [])

        store.data["exports"][export_id].update({"status": "processing", "progress": 20, "step": "Preparing export..."})
        store.save()

        if fmt == "json":
            payload = _segments_to_project_json(project_id, project)
            output_path = export_dir / f"{project_id}_project.json"
            _write_text_file(output_path, json.dumps(payload, ensure_ascii=False, indent=2))
            mime = "application/json"
        elif fmt == "srt":
            output_path = export_dir / f"{project_id}_captions.srt"
            _write_text_file(output_path, _segments_to_srt(captions))
            mime = "application/x-subrip"
        elif fmt == "vtt":
            output_path = export_dir / f"{project_id}_captions.vtt"
            _write_text_file(output_path, _segments_to_vtt(captions))
            mime = "text/vtt"
        elif fmt == "ass":
            output_path = export_dir / f"{project_id}_captions.ass"
            ass_renderer.generate_custom_ass(captions, str(output_path), style=style)
            mime = "text/plain"
        else:
            output_path = export_dir / f"{project_id}_captioned.mp4"
            ass_path = export_dir / f"{project_id}_captions.ass"
            ass_renderer.generate_custom_ass(captions, str(ass_path), style=style)
            ass_renderer.export_video(video_path, str(ass_path), str(output_path))
            mime = "video/mp4"

        store.data["exports"][export_id].update(
            {
                "status": "completed",
                "progress": 100,
                "step": "Export complete",
                "output_path": str(output_path),
                "mime_type": mime,
                "updated_at": now(),
            }
        )
        store.save()
    except Exception as exc:
        store.data["exports"].setdefault(export_id, {})
        store.data["exports"][export_id].update(
            {
                "status": "error",
                "progress": 0,
                "step": f"Error: {exc}",
                "error": str(exc),
                "updated_at": now(),
            }
        )
        store.save()


@app.get("/health")
async def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "version": "4.0.0",
        "product": "FYAP Pro",
        "features": [
            "Project-first editor shell",
            "Media import and asset library",
            "Caption generation and timeline editing",
            "Caption animation metadata",
            "Preview and export endpoints",
        ],
    }


@app.get("/projects")
async def list_projects() -> Dict[str, Any]:
    return {"projects": [_project_summary(p) for p in store.list_projects()]}


@app.post("/projects")
async def create_project(payload: ProjectCreateRequest) -> Dict[str, Any]:
    project_id = str(uuid.uuid4())
    project = _ensure_project_defaults(
        project_id,
        make_safe_name(payload.name),
        payload.description,
        payload.language,
        payload.display_mode,
    )
    store.set_project(project_id, project)
    store.data["jobs"][project_id] = {
        "id": project_id,
        "type": "project",
        "status": "created",
        "progress": 0,
        "step": "Project created",
        "project_id": project_id,
        "created_at": project["created_at"],
        "updated_at": now(),
    }
    store.save()
    return _project_detail(project)


@app.get("/projects/{project_id}")
async def get_project(project_id: str) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    return _project_detail(project)


@app.patch("/projects/{project_id}")
async def update_project(project_id: str, payload: ProjectUpdateRequest) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    updates = payload.model_dump(exclude_none=True)
    if "name" in updates:
        updates["name"] = make_safe_name(updates["name"])
    project.update(updates)
    project["updated_at"] = now()
    _save_project(project_id, project)
    return _project_detail(project)


@app.delete("/projects/{project_id}")
async def delete_project(project_id: str) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    assets = project.get("assets", [])
    for asset in assets:
        try:
            path = Path(asset.get("path", ""))
            if path.exists():
                path.unlink()
        except Exception:
            pass
    store.data["projects"].pop(project_id, None)
    store.data["jobs"].pop(project_id, None)
    store.save()
    return {"success": True}


@app.post("/projects/{project_id}/assets")
async def upload_asset(
    project_id: str,
    file: UploadFile = File(...),
    role: str = Form("source"),
) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    project_dir = MEDIA_DIR / project_id
    project_dir.mkdir(parents=True, exist_ok=True)

    asset_id = str(uuid.uuid4())
    safe_filename = make_safe_name(file.filename or f"asset_{asset_id}")
    dest = project_dir / f"{asset_id}_{safe_filename}"

    with dest.open("wb") as out:
        shutil.copyfileobj(file.file, out)

    meta = ffprobe(str(dest))
    duration = 0.0
    width = height = 0
    fps = 0.0
    try:
        duration = float(meta.get("format", {}).get("duration", 0) or 0)
    except Exception:
        duration = 0.0

    streams = meta.get("streams", []) or []
    for stream in streams:
        if stream.get("codec_type") == "video":
            width = int(stream.get("width", 0) or 0)
            height = int(stream.get("height", 0) or 0)
            fps = parse_fps(stream.get("r_frame_rate", "0/1"))
            break

    asset = {
        "id": asset_id,
        "name": file.filename or safe_filename,
        "safe_name": safe_filename,
        "role": role,
        "kind": media_kind(file.filename or safe_filename, file.content_type),
        "mime_type": file.content_type or mimetypes.guess_type(file.filename or "")[0] or "application/octet-stream",
        "path": str(dest),
        "size": dest.stat().st_size,
        "duration": duration,
        "width": width,
        "height": height,
        "fps": fps,
        "created_at": now(),
    }

    project.setdefault("assets", []).append(asset)
    if not project.get("active_asset_id") and asset["kind"] in {"video", "audio"}:
        project["active_asset_id"] = asset_id
    project["updated_at"] = now()
    project["status"] = project.get("status", "idle")
    _save_project(project_id, project)

    return {"success": True, "asset": _public_asset(project_id, asset), "project": _project_detail(project)}


@app.get("/projects/{project_id}/assets/{asset_id}/file")
async def get_asset_file(project_id: str, asset_id: str) -> FileResponse:
    project = _find_project_or_404(project_id)
    asset = _find_asset_or_404(project, asset_id)
    path = asset.get("path", "")
    if not path or not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Asset file not found")
    mime = asset.get("mime_type") or mimetypes.guess_type(path)[0] or "application/octet-stream"
    return FileResponse(path, media_type=mime, filename=Path(path).name)


@app.post("/projects/{project_id}/generate-captions")
async def generate_captions(
    project_id: str,
    background_tasks: BackgroundTasks,
    payload: GenerateCaptionsRequest,
) -> Dict[str, Any]:
    _find_project_or_404(project_id)
    store.data["jobs"][project_id] = {
        "id": project_id,
        "type": "caption_generation",
        "project_id": project_id,
        "status": "queued",
        "progress": 0,
        "step": "Queued for caption generation",
        "created_at": now(),
        "updated_at": now(),
    }
    store.save()
    background_tasks.add_task(
        _process_project_captions,
        project_id,
        payload.asset_id,
        payload.language,
        payload.display_mode,
    )
    return {"project_id": project_id, "status": "processing", "message": "Caption generation started"}


@app.get("/projects/{project_id}/timeline")
async def get_timeline(project_id: str) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    return timeline


@app.put("/projects/{project_id}/timeline")
async def replace_timeline(project_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    project["timeline"] = payload
    project["updated_at"] = now()
    _save_project(project_id, project)
    return {"success": True, "timeline": payload}


@app.patch("/projects/{project_id}/captions/{caption_id}")
async def update_caption(project_id: str, caption_id: str, payload: CaptionUpdateRequest) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    timeline_obj = Timeline.from_dict(timeline)
    editor = TimelineEditor(timeline_obj)
    updated = editor.update_caption(
        caption_id,
        text=payload.text,
        start=payload.start,
        end=payload.end,
        style=payload.style,
        animation=payload.animation,
        position=payload.position,
        emphasis=payload.emphasis,
    )
    if not updated:
        raise HTTPException(status_code=404, detail="Caption not found")
    project["timeline"] = timeline_obj.to_dict()
    project["updated_at"] = now()
    _save_project(project_id, project)
    return {"success": True, "caption": updated.to_dict()}


@app.delete("/projects/{project_id}/captions/{caption_id}")
async def delete_caption(project_id: str, caption_id: str) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    timeline_obj = Timeline.from_dict(timeline)
    editor = TimelineEditor(timeline_obj)
    if not editor.delete_caption(caption_id):
        raise HTTPException(status_code=404, detail="Caption not found")
    project["timeline"] = timeline_obj.to_dict()
    project["updated_at"] = now()
    _save_project(project_id, project)
    return {"success": True}


@app.post("/projects/{project_id}/captions/{caption_id}/split")
async def split_caption(project_id: str, caption_id: str, split_at: float = Form(...)) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    timeline_obj = Timeline.from_dict(timeline)
    editor = TimelineEditor(timeline_obj)
    result = editor.split_caption(caption_id, split_at)
    if not result:
        raise HTTPException(status_code=400, detail="Cannot split caption at this point")
    project["timeline"] = timeline_obj.to_dict()
    project["updated_at"] = now()
    _save_project(project_id, project)
    return {"success": True, "captions": [cap.to_dict() for cap in result]}


@app.post("/projects/{project_id}/captions/{caption_id}/merge-next")
async def merge_caption(project_id: str, caption_id: str) -> Dict[str, Any]:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    timeline_obj = Timeline.from_dict(timeline)
    editor = TimelineEditor(timeline_obj)
    result = editor.merge_caption_with_next(caption_id)
    if not result:
        raise HTTPException(status_code=400, detail="Cannot merge caption")
    project["timeline"] = timeline_obj.to_dict()
    project["updated_at"] = now()
    _save_project(project_id, project)
    return {"success": True, "caption": result.to_dict()}


@app.get("/projects/{project_id}/preview")
async def preview(project_id: str) -> JSONResponse:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    asset = _find_asset_or_404(project, project.get("active_asset_id"))
    video_url = f"/projects/{project_id}/assets/{asset['id']}/file"
    preview_data = preview_renderer.render_for_browser(timeline, video_url)
    return JSONResponse(content=preview_data)


@app.get("/projects/{project_id}/preview-html")
async def preview_html(project_id: str) -> FileResponse:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    asset = _find_asset_or_404(project, project.get("active_asset_id"))
    video_url = f"/projects/{project_id}/assets/{asset['id']}/file"
    html_path = PREVIEWS_DIR / f"{project_id}_preview.html"
    preview_renderer.generate_html_preview(timeline, video_url, str(html_path))
    return FileResponse(html_path, media_type="text/html")


@app.post("/projects/{project_id}/export")
async def export_project(
    project_id: str,
    background_tasks: BackgroundTasks,
    payload: ExportRequest,
) -> Dict[str, Any]:
    _find_project_or_404(project_id)
    export_id = str(uuid.uuid4())
    store.set_export(
        export_id,
        {
            "id": export_id,
            "project_id": project_id,
            "format": payload.format,
            "style": payload.style,
            "animation": payload.animation,
            "status": "queued",
            "progress": 0,
            "step": "Queued",
            "created_at": now(),
            "updated_at": now(),
        },
    )
    background_tasks.add_task(_run_export_job, export_id, project_id, payload.format, payload.style, payload.animation)
    return {"export_id": export_id, "status": "queued"}


@app.get("/export/{export_id}")
async def get_export(export_id: str) -> Dict[str, Any]:
    export = store.get_export(export_id)
    if not export:
        raise HTTPException(status_code=404, detail="Export not found")
    payload = copy.deepcopy(export)
    if payload.get("status") == "completed":
        payload["download_url"] = f"/download/{export_id}"
    return payload


@app.get("/download/{export_id}")
async def download_export(export_id: str) -> FileResponse:
    export = store.get_export(export_id)
    if not export:
        raise HTTPException(status_code=404, detail="Export not found")
    if export.get("status") != "completed":
        raise HTTPException(status_code=400, detail="Export not ready")
    output_path = export.get("output_path", "")
    if not output_path or not os.path.exists(output_path):
        raise HTTPException(status_code=404, detail="Export file not found")
    mime = export.get("mime_type") or mimetypes.guess_type(output_path)[0] or "application/octet-stream"
    return FileResponse(output_path, media_type=mime, filename=Path(output_path).name)


@app.get("/themes")
async def list_themes() -> Dict[str, Any]:
    return {
        "themes": [
            {"id": "default", "name": "Default", "description": "Clean white captions"},
            {"id": "bold", "name": "Bold", "description": "Heavy subtitle presentation"},
            {"id": "gold", "name": "Gold", "description": "Premium gold styling"},
            {"id": "fire", "name": "Fire", "description": "High-energy accent styling"},
        ]
    }


@app.get("/styles")
async def list_styles() -> Dict[str, Any]:
    return {
        "styles": [
            {"id": "default", "name": "Default"},
            {"id": "bold", "name": "Bold"},
            {"id": "gold", "name": "Gold"},
            {"id": "fire", "name": "Fire"},
        ],
        "animations": [
            {"id": "pop_in", "name": "Pop In"},
            {"id": "fade", "name": "Fade"},
            {"id": "slide_up", "name": "Slide Up"},
            {"id": "typewriter", "name": "Typewriter"},
            {"id": "karaoke", "name": "Karaoke"},
            {"id": "none", "name": "None"},
        ],
    }


@app.get("/job/{job_id}")
async def get_job_status(job_id: str) -> Dict[str, Any]:
    if job_id in store.data["projects"]:
        return _project_summary(store.data["projects"][job_id])
    if job_id in store.data["exports"]:
        export = copy.deepcopy(store.data["exports"][job_id])
        if export.get("status") == "completed":
            export["download_url"] = f"/download/{job_id}"
        return export
    if job_id in store.data["jobs"]:
        return copy.deepcopy(store.data["jobs"][job_id])
    raise HTTPException(status_code=404, detail="Job not found")


@app.get("/video/{project_id}")
async def serve_video(project_id: str) -> FileResponse:
    project = _find_project_or_404(project_id)
    asset = _find_asset_or_404(project, project.get("active_asset_id"))
    path = asset.get("path", "")
    if not path or not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Video file not found")
    mime = asset.get("mime_type") or mimetypes.guess_type(path)[0] or "video/mp4"
    return FileResponse(path, media_type=mime, filename=Path(path).name)


@app.post("/upload")
async def upload_legacy(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    language: str = Form("auto"),
    display_mode: str = Form("hinglish"),
) -> Dict[str, Any]:
    create = ProjectCreateRequest(name=file.filename or "Untitled Project", language=language, display_mode=display_mode)
    project = await create_project(create)
    project_id = project["id"]
    await upload_asset(project_id, file)
    background_tasks.add_task(
        _process_project_captions,
        project_id,
        None,
        language,
        display_mode,
    )
    return {
        "job_id": project_id,
        "project_id": project_id,
        "status": "processing",
        "message": "Upload received and caption generation started",
    }


@app.post("/render")
async def render_legacy(
    background_tasks: BackgroundTasks,
    job_id: str = Form(...),
    theme: str = Form("default"),
    animation: str = Form("pop_in"),
) -> Dict[str, Any]:
    return await export_project(job_id, background_tasks, ExportRequest(format="mp4", style=theme, animation=animation))


@app.get("/render/{render_id}")
async def get_render_status(render_id: str) -> Dict[str, Any]:
    return await get_export(render_id)


@app.get("/export/project/{project_id}")
async def export_project_json_route(project_id: str) -> FileResponse:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    export_path = EXPORTS_DIR / f"{project_id}_project.json"
    payload = _segments_to_project_json(project_id, project)
    _write_text_file(export_path, json.dumps(payload, ensure_ascii=False, indent=2))
    return FileResponse(export_path, media_type="application/json", filename=f"{project_id}_project.json")


@app.get("/export/ass/{project_id}")
async def export_ass_route(project_id: str) -> FileResponse:
    project = _find_project_or_404(project_id)
    timeline = project.get("timeline")
    if not timeline:
        raise HTTPException(status_code=404, detail="Timeline not found")
    export_path = EXPORTS_DIR / f"{project_id}_captions.ass"
    ass_renderer.generate_custom_ass(timeline.get("captions", []), str(export_path), style="default")
    return FileResponse(export_path, media_type="text/plain", filename=f"{project_id}_captions.ass")


@app.post("/export/video/{project_id}")
async def export_video_route(
    background_tasks: BackgroundTasks,
    project_id: str,
    style: str = Form("default"),
) -> Dict[str, Any]:
    return await export_project(project_id, background_tasks, ExportRequest(format="mp4", style=style, animation="pop_in"))


@app.get("/export/status/{export_id}")
async def export_status_route(export_id: str) -> Dict[str, Any]:
    return await get_export(export_id)


@app.get("/export/download/{export_id}")
async def export_download_route(export_id: str) -> FileResponse:
    return await download_export(export_id)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
