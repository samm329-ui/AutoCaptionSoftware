"""
hinglish_processor.py — DEPRECATED, DO NOT USE FOR NEW CODE

This file is kept only so old imports don't crash.
All logic has moved to text_normalizer.py (conversion) and
display_processor.py (formatting).

DO NOT ADD LANGUAGE CONVERSION LOGIC HERE.
"""

from text_normalizer import normalize_word, normalize_words, detect_emphasis
from display_processor import HinglishProcessor  # re-export for any stale imports

__all__ = ["HinglishProcessor", "normalize_word", "normalize_words", "detect_emphasis"]
