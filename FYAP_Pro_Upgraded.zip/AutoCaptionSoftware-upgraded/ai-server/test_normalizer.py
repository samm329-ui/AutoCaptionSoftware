"""
Quick local test for text_normalizer.py
Run: python test_normalizer.py
No external dependencies needed.
"""
import sys
sys.path.insert(0, ".")

from text_normalizer import normalize_word, normalize_words, detect_emphasis

# ── Test cases: (input, expected_contains) ──────────────────────────────────
tests = [
    # Pure Devanagari (common map)
    ("है",      "hai"),
    ("नहीं",   "nahi"),
    ("क्या",   "kya"),
    ("बहुत",   "bahut"),
    ("मैं",    "main"),
    ("ठीक",    "theek"),
    ("और",     "aur"),
    # Pure English → unchanged
    ("real",   "real"),
    ("views",  "views"),
    ("hello",  "hello"),
    # Urdu / Arabic script — should produce Roman output or empty
    ("ہے",     ""),   # common Urdu word for 'hai' — may not map perfectly
    ("کچھ",   ""),
    # Mixed Devanagari + English (should keep English part)
    ("call",   "call"),
    # Numbers → unchanged
    ("100",    "100"),
]

passed = 0
failed = 0
for word, expected in tests:
    result = normalize_word(word)
    ok = expected.lower() in result.lower() if expected else True
    status = "✅" if ok else "❌"
    print(f"{status}  '{word}' → '{result}'  (expected contains: '{expected}')")
    if ok:
        passed += 1
    else:
        failed += 1

print(f"\n{passed} passed, {failed} failed")

# ── Test word list normalization ──────────────────────────────────────────────
print("\n── normalize_words() test ──")
words = [
    {"text": "real", "start": 0.0, "end": 0.3, "lang": "en"},
    {"text": "views", "start": 0.3, "end": 0.6, "lang": "en"},
    {"text": "ہے",   "start": 0.6, "end": 0.9, "lang": "ur"},
    {"text": "है",   "start": 0.9, "end": 1.1, "lang": "hi"},
    {"text": "कुछ",  "start": 1.1, "end": 1.4, "lang": "hi"},
    {"text": "नहीं", "start": 1.4, "end": 1.7, "lang": "hi"},
]

normalized = normalize_words(words)
for w in normalized:
    print(f"  '{w['original']}' → '{w['text']}'")

print("\n── detect_emphasis() test ──")
text = "Real views bahut zyada hain nahi kya"
emphasis = detect_emphasis(text)
for e in emphasis:
    print(f"  '{e['word']}' → {e['type']}")
