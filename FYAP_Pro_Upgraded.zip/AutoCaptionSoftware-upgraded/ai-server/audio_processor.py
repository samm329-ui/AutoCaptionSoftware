"""
Audio Processing Module
Extract audio from video, get video metadata.

FFmpeg: auto-detected from PATH, or set FFMPEG_BIN env variable.
"""

import subprocess
import json
import os
import shutil
from pathlib import Path
from typing import Dict, Any


def _get_ffmpeg_exe() -> str:
    custom_bin = os.environ.get("FFMPEG_BIN", "")
    if custom_bin:
        for name in ["ffmpeg.exe", "ffmpeg"]:
            candidate = os.path.join(custom_bin, name)
            if os.path.isfile(candidate):
                return candidate
    found = shutil.which("ffmpeg")
    if found:
        return found
    raise RuntimeError(
        "ffmpeg not found. Install ffmpeg and add it to PATH, "
        "or set FFMPEG_BIN environment variable."
    )


def _get_ffprobe_exe() -> str:
    custom_bin = os.environ.get("FFMPEG_BIN", "")
    if custom_bin:
        for name in ["ffprobe.exe", "ffprobe"]:
            candidate = os.path.join(custom_bin, name)
            if os.path.isfile(candidate):
                return candidate
    found = shutil.which("ffprobe")
    if found:
        return found
    raise RuntimeError("ffprobe not found.")


def extract_audio(
    video_path: str,
    output_dir: str = "./storage/audio",
    sample_rate: int = 16000
) -> str:
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    video_name = Path(video_path).stem
    audio_path = str(Path(output_dir) / f"{video_name}.wav")

    cmd = [
        _get_ffmpeg_exe(),
        "-i", video_path,
        "-vn",
        "-acodec", "pcm_s16le",
        "-ar", str(sample_rate),
        "-ac", "1",
        "-y",
        audio_path
    ]

    try:
        subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=300)
        print(f"Audio extracted: {audio_path}")
        return audio_path
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to extract audio: {e.stderr}")
    except subprocess.TimeoutExpired:
        raise RuntimeError("Audio extraction timed out (>5 minutes)")


def get_video_info(video_path: str) -> Dict[str, Any]:
    cmd = [
        _get_ffprobe_exe(),
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        video_path
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=30)
        data = json.loads(result.stdout)

        video_stream = next(
            (s for s in data.get("streams", []) if s.get("codec_type") == "video"),
            None
        )

        if not video_stream:
            raise ValueError("No video stream found")

        fps_str = video_stream.get("r_frame_rate", "30/1")
        if "/" in fps_str:
            num, den = map(float, fps_str.split("/"))
            fps = num / den if den != 0 else 30.0
        else:
            fps = float(fps_str)

        return {
            "width": int(video_stream.get("width", 1920)),
            "height": int(video_stream.get("height", 1080)),
            "fps": fps,
            "duration": float(data.get("format", {}).get("duration", 0)),
            "codec": video_stream.get("codec_name", "unknown"),
            "bitrate": int(data.get("format", {}).get("bit_rate", 0))
        }

    except Exception as e:
        print(f"Could not get video info: {e}")
        return {"width": 1920, "height": 1080, "fps": 30.0, "duration": 0, "codec": "unknown", "bitrate": 0}


def get_video_duration(video_path: str) -> float:
    return get_video_info(video_path).get("duration", 0)
